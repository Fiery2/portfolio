// Fill out your copyright notice in the Description page of Project Settings.


#include "LaserBeamAmmo.h"

#include "AIEnemyParent.h"
#include "NetworkChar.h"
#include "Components/SphereComponent.h"

#include "GameFramework/ProjectileMovementComponent.h"

#define COLLISION_PLAYER	ECC_GameTraceChannel2
ALaserBeamAmmo::ALaserBeamAmmo()
{
	//set mesh 
	static ConstructorHelpers::FObjectFinder<UStaticMesh>MeshAsset(TEXT("StaticMesh'/Game/BLAST/Gameplay/WepSys/Cylinder.Cylinder'"));
	UStaticMesh* Asset = MeshAsset.Object;
	Mesh1P->SetStaticMesh(Asset);
	Mesh1P->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	Mesh1P->SetCollisionResponseToChannel(COLLISION_PLAYER,ECR_Overlap);
	CollisionComp->SetCollisionResponseToChannel(COLLISION_PLAYER,ECR_Overlap);
	
	//Set Niagara variable

	static ConstructorHelpers::FObjectFinder<UNiagaraSystem>NiagaraAsset(TEXT("NiagaraSystem'/Game/BLAST/FX/NES/NE_Laser.NE_Laser'"));
	ProjectileVfxEmitterSystem = NiagaraAsset.Object;
	ProjectileVfxEmitterComponent->SetAsset(ProjectileVfxEmitterSystem);

	static ConstructorHelpers::FObjectFinder<UNiagaraSystem>NiagaraAsset3(TEXT("NiagaraSystem'/Game/BLAST/FX/NES/NE_LaserHit.NE_LaserHit'"));
	HitVfxEmitterSystem = NiagaraAsset3.Object;
	HitVfxEmitterComponent->SetAsset(HitVfxEmitterSystem);
	MuzzleVfxEmitterSystem = nullptr;
	MuzzleVfxEmitterComponent->SetAsset(MuzzleVfxEmitterSystem);
	ProjectileMovement->SetVelocityInLocalSpace(FVector(0,0,0));
	//set AmmoUnique variables
	Damage = 5.0;
	AmmoCount=200;
	Lifespan = 0.0f;
	bHasLifespan=false;
	AmmoFireTime=0.0f;
	bHasCollision= false;
	bFades = true;
	TimeUntilDeletion = 0.5f;
	
}

void ALaserBeamAmmo::BeginPlay()
{
	Super::BeginPlay();
	//make sure object isn't deleted 
	SetLifeSpan(0.0f);
	Mesh1P->SetVisibility(false);
	
}
void ALaserBeamAmmo::TraceLine()
{
	//start of ray
	FVector TraceStart= MuzzleLocation;
	//location of furthest distance to ray trace too
	FVector TraceEnd; 
	ANetworkChar* OwnerPlayer = Cast<ANetworkChar>(GetOwner());
	if(OwnerPlayer != nullptr)
	{
		//get player camera facing
		FVector PlayerCameraLook = OwnerPlayer->GetCamera()->GetForwardVector();
		TraceEnd= MuzzleLocation+PlayerCameraLook*MaxLaserRange;
	}
	else
	{
		if(GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1,1.0f,FColor::Red,TEXT("Failed to cast to ANetworkChar in laser trace."));
		}
	}
	//ignore player that fired it just in case
	const AActor* ActorToIgnore = GetOwner();
	//set up trace parameters
	FCollisionQueryParams TraceParams(FName(TEXT("RayTracing")), true, ActorToIgnore);
	TraceParams.bReturnPhysicalMaterial = false;
	TraceParams.bTraceComplex = true;

	FHitResult HitResult(ForceInit);
	
	//ray trace check for first collision 
	bool HadHit = GetWorld()->LineTraceSingleByChannel(HitResult, TraceStart, TraceEnd, ECC_Visibility, TraceParams);
	
	//if the ray trace hit something
	if (HadHit)
	{
		// setting vfx info with having a hit
		if(HitResult.IsValidBlockingHit())
		{
			ProjectileVfxEmitterComponent->SetVectorParameter(FName("User.End"),HitResult.ImpactPoint);
		}
		else
		{
			ProjectileVfxEmitterComponent->SetVectorParameter(FName("User.End"),HitResult.TraceEnd);
		}
		
		//is it a player
		ANetworkChar* EnemyPlayer = Cast<ANetworkChar>(HitResult.GetActor());
		if (EnemyPlayer)
		{
			EnemyPlayer->SetCurrentHealth(DealDamage(EnemyPlayer->GetCurrentHealth(),Damage,EnemyPlayer->GetMaxHealth()));
		}
		//is it an AI
		AAIEnemyParent* Enemy = Cast<AAIEnemyParent>(HitResult.GetActor());
		if (Enemy)
		{
			Enemy->SetCurrentHealth(DealDamage(Enemy->GetCurrentHealth(),Damage,Enemy->GetTotalHealth()));
		}
	}
	else	// if we dont have a hit then we still want to shoot a laser
	{
		if(HitResult.IsValidBlockingHit())
		{
			ProjectileVfxEmitterComponent->SetVectorParameter(FName("User.End"), TraceEnd);
		}
		else
		{
			ProjectileVfxEmitterComponent->SetVectorParameter(FName("User.End"), TraceEnd);
		}
	}

		
}
void ALaserBeamAmmo::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
	
	/**
	 *another version of aligning projectile with "muzzle" no matter the direction looked.
	 * needs a scaler for movment
	 */
	if(!bIsInstance){
	ANetworkChar* TheOwningPlayer = Cast<ANetworkChar>(GetOwner());
    	if(TheOwningPlayer == nullptr)
    	{
    		if(GEngine)
    		{
    			GEngine->AddOnScreenDebugMessage(-1,1.0f,FColor::Red,TEXT("Failed to cast to ANetworkChar."));
    		}
    		return;
    	}
    	//Set the flame to the muzzle location with calculations that will be used below
    	
    	FVector PlayerCameraLook = TheOwningPlayer->GetCamera()->GetForwardVector();
    	
    	PlayerCameraLook.Normalize();
    
    	const FVector PlayerLocation = TheOwningPlayer->GetActorLocation();
    	
    	Mesh1P->SetWorldLocation(PlayerLocation + PlayerCameraLook * TheOwningPlayer->MuzzleOffset.X);
    
    	//Set the flame to the player angle with calculations that will be used below
    
    	const FRotator PlayerRotation = TheOwningPlayer->GetCamera()->GetRelativeRotation();
    	
    	const FRotator NewRotation = {PlayerRotation.Pitch+90,GetActorRotation().Yaw,GetActorRotation().Roll};
    
    	Mesh1P->SetWorldRotation(NewRotation);
    
    	//Set the Niagara System location
    
    	ProjectileVfxEmitterComponent->SetWorldLocation(PlayerLocation + PlayerCameraLook * TheOwningPlayer->MuzzleOffset.X);
    	ProjectileVfxEmitterComponent->SetWorldRotation(NewRotation);
		//raytrace to find the first available object in a line and damage if applies
		TraceLine();
	}
	
}

void ALaserBeamAmmo::OnOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor,
                               UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult)
{
	Super::OnOverlap(OverlappedComponent, OtherActor, OtherComp, OtherBodyIndex, bFromSweep, SweepResult);
	//when an object enters line of fire add to array, may not need
	AffectedEnemies.Add(OtherActor);
}

void ALaserBeamAmmo::OnEndOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor,
									UPrimitiveComponent* OtherComp, int32 OtherBodyIndex)
{
	Super::OnEndOverlap(OverlappedComponent, OtherActor, OtherComp, OtherBodyIndex);
	//when an object leaves line of fire remove from array may not need
	if(AffectedEnemies.Find(OtherActor)!=INDEX_NONE)
	{
		AffectedEnemies.Remove(OtherActor);
	}
}
