// Fill out your copyright notice in the Description page of Project Settings.


#include "RocketLauncherAmmo.h"

#include "AIEnemyParent.h"
#include "CollisionDebugDrawingPublic.h"
#include "DrawDebugHelpers.h"
#include "NetworkChar.h"
#include "Kismet/KismetSystemLibrary.h"
#include "Components/SphereComponent.h"

ARocketLauncherAmmo::ARocketLauncherAmmo() : AAmmoBase()
{
	//set mesh 
	static ConstructorHelpers::FObjectFinder<UStaticMesh>MeshAsset(TEXT("StaticMesh'/Game/BLAST/Gameplay/WepSys/bullet.bullet'"));
	UStaticMesh* Asset = MeshAsset.Object;
	Mesh1P->SetStaticMesh(Asset);
	Mesh1P->SetRelativeScale3D(FVector(0.1,0.1,0.1));
	Mesh1P->SetVisibility(false);
	//setup niagara details
	static ConstructorHelpers::FObjectFinder<UNiagaraSystem>NiagaraAsset(TEXT("NiagaraSystem'/Game/BLAST/FX/NES/NE_Projectile_RocketLauncherNew.NE_Projectile_RocketLauncherNew'"));
	ProjectileVfxEmitterSystem = NiagaraAsset.Object;
	ProjectileVfxEmitterComponent->SetAsset(ProjectileVfxEmitterSystem);

	//static ConstructorHelpers::FObjectFinder<UNiagaraSystem>NiagaraAsset2(TEXT("NiagaraSystem'/Game/BLAST/FX/NES/NE_Muzzle_RocketLauncher.NE_Muzzle_RocketLauncher'"));
	MuzzleVfxEmitterSystem =nullptr;
	MuzzleVfxEmitterComponent->SetAsset(MuzzleVfxEmitterSystem);
	static ConstructorHelpers::FObjectFinder<UNiagaraSystem>NiagaraAsset3(TEXT("NiagaraSystem'/Game/BLAST/FX/NES/NE_Hit_RocketLauncherNew.NE_Hit_RocketLauncherNew'"));
	HitVfxEmitterSystem = NiagaraAsset3.Object;
	HitVfxEmitterComponent->SetAsset(HitVfxEmitterSystem);
	//set AmmoUnique variables
	DrawDebugTime = 2.0f;
	Damage = 50;
	AmmoCount=10;
	Lifespan = 1.5f;
	bHasLifespan = true;
	AmmoFireTime=0.6f;
}

void ARocketLauncherAmmo::BeginPlay()
{
	Super::BeginPlay();
	
	//replication of bullets
	bReplicates = true;
}

void ARocketLauncherAmmo::AoeDamage()
{
	
	//add object types the aoe will affect to its list
	ObjectTypes.Add(UEngineTypes::ConvertToObjectType(ECollisionChannel::ECC_Pawn));
	//add actors the aoe will ignore to its list
	ActorsToIgnore.Add(GetInstigator());
	//get list of all actors affected by the aoe 
	TArray<AActor*> OverlappedActors;
	UKismetSystemLibrary::SphereOverlapActors(GetWorld(),CollisionComp->GetComponentLocation(),ExplosionRadius,ObjectTypes,nullptr,ActorsToIgnore,OverlappedActors);
	//go through that list and damage all enemies
	for (AActor* OverlappedActor : OverlappedActors)
	{
		//draw sphere for debugging
		/*if(DrawDebugTime>0.0)
		{
			DrawDebugSphere(GetWorld(),CollisionComp->GetComponentLocation(),ExplosionRadius,12,FColor::Red,false,DrawDebugTime,SDPG_World,2.0);
		}*/
		//if its an AI
		AAIEnemyParent* EnemyAI = Cast<AAIEnemyParent>(OverlappedActor);
		if (EnemyAI)
		{
			EnemyAI->SetCurrentHealth(DealDamage(EnemyAI->GetCurrentHealth(),Damage,EnemyAI->GetTotalHealth()));	
		}
		//if its a player
		ANetworkChar* EnemyPlayer = Cast<ANetworkChar>(OverlappedActor);
		if (EnemyPlayer)
		{
			EnemyPlayer->GetMesh()->AddRadialImpulse(this->GetActorLocation(),ExplosionRadius,PushPower,RIF_Linear);
			EnemyPlayer->SetCurrentHealth(DealDamage(EnemyPlayer->GetCurrentHealth(),Damage,EnemyPlayer->GetMaxHealth()));	
		}
	}
}

void ARocketLauncherAmmo::OnHit(UPrimitiveComponent* HitComp, AActor* OtherActor, UPrimitiveComponent* OtherComp,
                                FVector NormalImpulse, const FHitResult& Hit)
{
	Super::OnHit(HitComp, OtherActor, OtherComp, NormalImpulse, Hit);
	//deal damage and knockback
	AoeDamage();

}

void ARocketLauncherAmmo::OnOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor,
	UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult)
{
	Super::OnOverlap(OverlappedComponent, OtherActor, OtherComp, OtherBodyIndex, bFromSweep, SweepResult);	
	AoeDamage();
}
