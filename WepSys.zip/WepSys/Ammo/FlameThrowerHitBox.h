﻿#pragma once

#include "GameFramework/GameMode.h"
#include "Components/BoxComponent.h"
#include "Components/SphereComponent.h"
#include "GameFrameWork/ProjectileMovementComponent.h"
#include "FlameThrowerHitBox.generated.h"

/**This class is to be spawned periodically as a stream of boxes. Damage will be calculated upon overlap of this class's collision box*/
UCLASS()
class BLAST_API AFlameThrowerHitBox : public AActor
{
	GENERATED_BODY()
public:
	/**Constructor
	 * 
	 */
	AFlameThrowerHitBox();

	/**BeginPlay.
	 * 
	 */
	virtual void BeginPlay() override;

	/** Called every frame
	 * 
	 */
	virtual void Tick(float DeltaSeconds) override;
		
	/**Returns the HasHit bool.
	 * 
	 */
	UFUNCTION()
	bool GetHasHit() const;

	/**Sets the lifetime value of this class
	 * 
	 */
	UFUNCTION()
	void SetTimer(float NewTime);

	protected:
	/**Projectile Speed
	 * 
	 */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="MovementValues")
	float Speed;

	/**The UBoxComponent that will be used for collision
	 * 
	 */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="CollisionBox")
	UBoxComponent* CollisionMesh = nullptr;
	
	/**The ProjectileMovementComponent that operates the movement of the hitbox
	 * 
	 */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="MovementValues")
	UProjectileMovementComponent* ProjectileMovement = nullptr;

	/**This bool will be updated when the collsionmesh interacts with a valid actor.
	 */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="MovementValues")
	bool bHasHit;

	/**The time before deletion of this class
	 * @Note Counts down in Tick()
	 */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="Misc")
	float LifeTime;

	/**The Damage that will be applied to a valid actor that interacts with the CollisionMesh
	 *
	 */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category="Misc")
	float DamageValue;

	/** called when projectile overlaps something 
	* @param OverlappedComponent component that overlapped
	* @param OtherActor other actor that was overlapped
	* @param OtherComp other component that overlapped
	* @param OtherBodyIndex index the other object is
	* @param bFromSweep if theres a sweep
	* @param SweepResult hit result from the sweep
	*/
	UFUNCTION()
	virtual void OnOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult & SweepResult);
	
};

