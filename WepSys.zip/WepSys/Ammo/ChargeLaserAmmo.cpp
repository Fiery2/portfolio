// Fill out your copyright notice in the Description page of Project Settings.


#include "ChargeLaserAmmo.h"

#include "AIEnemyParent.h"
#include "NetworkChar.h"
#include "Kismet/GameplayStatics.h"

AChargeLaserAmmo::AChargeLaserAmmo()
{
	//set mesh 
	static ConstructorHelpers::FObjectFinder<UStaticMesh>MeshAsset(TEXT("StaticMesh'/Game/BLAST/Gameplay/WepSys/Sphere.Sphere'"));
	UStaticMesh* Asset = MeshAsset.Object;
	Mesh1P->SetStaticMesh(Asset);
	//setup niagara details
	static ConstructorHelpers::FObjectFinder<UNiagaraSystem>NiagaraAsset(TEXT("NiagaraSystem'/Game/BLAST/FX/NES/NE_Projectile_RailGun.NE_Projectile_RailGun'"));
	ProjectileVfxEmitterSystem = NiagaraAsset.Object;
	ProjectileVfxEmitterComponent->SetAsset(ProjectileVfxEmitterSystem);
	static ConstructorHelpers::FObjectFinder<UNiagaraSystem>NiagaraAsset2(TEXT("NiagaraSystem'/Game/BLAST/FX/NES/NE_Muzzle_RailGun.NE_Muzzle_RailGun'"));
	MuzzleVfxEmitterSystem = NiagaraAsset2.Object;
	MuzzleVfxEmitterComponent->SetAsset(MuzzleVfxEmitterSystem);
	static ConstructorHelpers::FObjectFinder<UNiagaraSystem>NiagaraAsset3(TEXT("NiagaraSystem'/Game/BLAST/FX/NES/NE_Hit_RailGun.NE_Hit_RailGun'"));
	HitVfxEmitterSystem = NiagaraAsset3.Object;
	HitVfxEmitterComponent->SetAsset(HitVfxEmitterSystem);
	//set AmmoUnique variables
	Damage = 100;
	AmmoCount=5;
	Lifespan=1.1f;
	bHasLifespan = true;
	AmmoFireTime=0.5f;
	
	
}

void AChargeLaserAmmo::BeginPlay()
{
	Super::BeginPlay();
	
	
	//replication of bullets
	bReplicates = true;
}





