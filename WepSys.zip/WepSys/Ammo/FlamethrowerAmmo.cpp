// Fill out your copyright notice in the Description page of Project Settings.


#include "FlamethrowerAmmo.h"

#include <DirectXMath.h>

#include "AIEnemyParent.h"
#include "NetworkChar.h"
#include "GameFramework/ProjectileMovementComponent.h"


AFlamethrowerAmmo::AFlamethrowerAmmo()
{
	/**unset mesh and set AmmoUnique variables*/
	Mesh1P->SetStaticMesh(nullptr);
	
	/**General value initialization*/
	Damage = 1;
	AmmoCount=100;
	Lifespan=0.0f;
	bHasLifespan = false;;
	AmmoFireTime=0.0f;
    bHasCollision= false;
	TimeUntilDeletion = 0.3f;

	/**Hitbox spawn timers*/
	TimeToSpawnDefault = 0.1;
	TimeToSpawnNextHitBox = TimeToSpawnDefault;
	
	/**Set Niagra variable*/
	static ConstructorHelpers::FObjectFinder<UNiagaraSystem>NiagaraAsset(TEXT("NiagaraSystem'/Game/BLAST/FX/NES/NS_FlameThrower_A.NS_FlameThrower_A'"));
	ProjectileVfxEmitterSystem = NiagaraAsset.Object;
	ProjectileVfxEmitterComponent->SetAsset(ProjectileVfxEmitterSystem);
	ProjectileVfxEmitterComponent->SetCollisionEnabled(ECollisionEnabled::QueryOnly);
	MuzzleVfxEmitterSystem=nullptr;
	MuzzleVfxEmitterComponent->SetAsset(MuzzleVfxEmitterSystem);
	HitVfxEmitterSystem = nullptr;
	HitVfxEmitterComponent->SetAsset(HitVfxEmitterSystem);
	/**Set ProjectileMovement*/
	ProjectileMovement->SetVelocityInLocalSpace(FVector(0,0,0));
}

void AFlamethrowerAmmo::BeginPlay()
{
	Super::BeginPlay();
	//make sure object isn't deleted 
	SetLifeSpan(0.0f);
	
}
void AFlamethrowerAmmo::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
	
	/**Set the Niagara System location*/
	if(!bIsInstance)
	{
		const FRotator NewPlayerRotationForMuzzle = {PlayerRotationForMuzzle.Pitch-90,PlayerRotationForMuzzle.Yaw,PlayerRotationForMuzzle.Roll};
		ProjectileVfxEmitterComponent->SetWorldLocation(MuzzleLocation);
		ProjectileVfxEmitterComponent->SetWorldRotation(NewPlayerRotationForMuzzle);
	
	
		/**Only do this stuff if the flamethrower isn't being destroyed*/
		if(!bReadyToDie)
		{
			if(TimeToSpawnNextHitBox <= 0.0)
			{
				/**Create the FlameThrowerHitBox, the class that I (Hayden Ridgeway) made to deal with the unique properties of a flamethrower*/
				FActorSpawnParameters ActorSpawnParams;
				ActorSpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AdjustIfPossibleButDontSpawnIfColliding;
				ActorSpawnParams.Owner = GetOwner();
				ActorSpawnParams.Instigator = GetInstigator();
				AFlameThrowerHitBox* NewHitBox = GetWorld()->SpawnActor<AFlameThrowerHitBox>(MuzzleLocation, NewPlayerRotationForMuzzle,ActorSpawnParams);
				
				
				TimeToSpawnNextHitBox = TimeToSpawnDefault;
			}
			else
			{
				TimeToSpawnNextHitBox-=DeltaTime;
			}
		}
	}
	/**Count down to deletion if set to die*/
	if(bReadyToDie)
	{
		if(TimeUntilDeletion <= 0.0)
		{
			this->Destroy();
		}
		else
			TimeUntilDeletion-=DeltaTime;
	}
	
}