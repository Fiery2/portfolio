﻿


#include "AmmoBase.h"

#include "AIEnemyParent.h"
#include "Husk.h"
#include "Math/Rotator.h"

#include "NetworkChar.h"
#include "GameFramework/ProjectileMovementComponent.h"
#include "Components/SphereComponent.h"
#include "GameFramework/CharacterMovementComponent.h"

#define COLLISION_PROJECTILE	ECC_GameTraceChannel1
#define COLLISION_PLAYER	ECC_GameTraceChannel2

class ANetworkChar;
// Sets default values
AAmmoBase::AAmmoBase()
{
	// Set this character to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;
	// Use a sphere as a simple collision representation
	//setup collision component details
	if (!CollisionComp)
	{
		CollisionComp = CreateDefaultSubobject<USphereComponent>(TEXT("SphereComp"));
		CollisionComp->BodyInstance.SetCollisionProfileName("Projectile");
		CollisionComp->OnComponentHit.AddDynamic(this, &AAmmoBase::OnHit);		// set up a notification for when this component hits something blocking
		CollisionComp->OnComponentBeginOverlap.AddDynamic(this, &AAmmoBase::OnOverlap);
		CollisionComp->OnComponentEndOverlap.AddDynamic(this, &AAmmoBase::OnEndOverlap);
		CollisionComp->SetEnableGravity(false);
		CollisionComp->SetSimulatePhysics(false);
		//Players can't walk on it
		CollisionComp->SetWalkableSlopeOverride(FWalkableSlopeOverride(WalkableSlope_Unwalkable, 0.f));
		CollisionComp->CanCharacterStepUpOn = ECB_No;
		CollisionComp->ComponentTags.Add("projectile");
	
		//Set as root component
		RootComponent = CollisionComp;
	}
	
	// Use a ProjectileMovementComponent to govern this projectile's movement
	if (!ProjectileMovement)
	{
		ProjectileMovement = CreateDefaultSubobject<UProjectileMovementComponent>(TEXT("ProjectileComp"));
		ProjectileMovement->SetUpdatedComponent(CollisionComp);
		ProjectileMovement->InitialSpeed = 3000;
		ProjectileMovement->MaxSpeed = 3000;
		ProjectileMovement->bRotationFollowsVelocity = true;
		ProjectileMovement->bShouldBounce = false;
		ProjectileMovement->Bounciness=0;
		ProjectileMovement->ProjectileGravityScale = 0;
		ProjectileMovement->bUpdateOnlyIfRendered=false;
	}
	
	//setup mesh details
	if (!Mesh1P)
	{
		Mesh1P = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("ProjectileMesh1P"));
		Mesh1P->SetupAttachment(RootComponent);
		Mesh1P->SetEnableGravity(false);
		Mesh1P->ComponentTags.Add("projectile");
		static ConstructorHelpers::FObjectFinder<UStaticMesh>MeshAsset(TEXT("StaticMesh'/Game/BLAST/Gameplay/WepSys/Sphere.Sphere'"));
		UStaticMesh* Asset = MeshAsset.Object;
		Mesh1P->SetStaticMesh(Asset);
		Mesh1P->SetRelativeScale3D(FVector(0.05,0.05,0.05));
		Mesh1P->SetVisibility(false);
	}

	//setup niagara details
	if(!ProjectileVfxEmitterComponent)
	{
		ProjectileVfxEmitterComponent = CreateDefaultSubobject<UNiagaraComponent>(TEXT("ProjectileNiagaraComponent"));
		ProjectileVfxEmitterComponent->SetupAttachment(RootComponent);
		ProjectileVfxEmitterComponent->ComponentTags.Add("projectile");
		static ConstructorHelpers::FObjectFinder<UNiagaraSystem>NiagaraAsset(TEXT("NiagaraSystem'/Game/BLAST/FX/NES/NE_Projectile_EnergyBall.NE_Projectile_EnergyBall'"));
		ProjectileVfxEmitterSystem = NiagaraAsset.Object;
		ProjectileVfxEmitterComponent->SetAsset(ProjectileVfxEmitterSystem);
		ProjectileVfxEmitterComponent->OnComponentBeginOverlap.AddDynamic(this, &AAmmoBase::OnOverlap);
		
	}
	if(!MuzzleVfxEmitterComponent)
	{
		MuzzleVfxEmitterComponent = CreateDefaultSubobject<UNiagaraComponent>(TEXT("ProjectileNiagaraComponent2"));
		MuzzleVfxEmitterComponent->SetupAttachment(RootComponent);
		MuzzleVfxEmitterComponent->ComponentTags.Add("projectile");
		MuzzleVfxEmitterComponent->SetAutoActivate(false);
		static ConstructorHelpers::FObjectFinder<UNiagaraSystem>NiagaraAsset2(TEXT("NiagaraSystem'/Game/BLAST/FX/NES/NE_Muzzle_EnergyBall.NE_Muzzle_EnergyBall'"));
		MuzzleVfxEmitterSystem = NiagaraAsset2.Object;
		MuzzleVfxEmitterComponent->SetAsset(MuzzleVfxEmitterSystem);
		
	}
	if(!HitVfxEmitterComponent)
	{
		HitVfxEmitterComponent = CreateDefaultSubobject<UNiagaraComponent>(TEXT("ProjectileNiagaraComponent3"));
		HitVfxEmitterComponent->ComponentTags.Add("projectile");
		HitVfxEmitterComponent->SetAutoActivate(false);
		static ConstructorHelpers::FObjectFinder<UNiagaraSystem>NiagaraAsset3(TEXT("NiagaraSystem'/Game/BLAST/FX/NES/NE_Hit_EnergyBall.NE_Hit_EnergyBall'"));
		HitVfxEmitterSystem = NiagaraAsset3.Object;
		HitVfxEmitterComponent->SetAsset(HitVfxEmitterSystem);

	}

	//cant hit player that shot it 
	Mesh1P->IgnoreActorWhenMoving(GetInstigator(),true);
	CollisionComp->IgnoreActorWhenMoving(GetInstigator(),true);

	//doesnt allow for collison with othe projectiles
	Mesh1P->SetCollisionObjectType(COLLISION_PROJECTILE);
	CollisionComp->SetCollisionObjectType(COLLISION_PROJECTILE);
	Mesh1P->SetCollisionResponseToChannel(COLLISION_PROJECTILE,ECR_Ignore);
	CollisionComp->SetCollisionResponseToChannel(COLLISION_PROJECTILE,ECR_Ignore);
	
	//set base damage
	Damage=15;
	AmmoFireTime=0.1;
	// Die after 1 seconds by default
	Lifespan = 1.0f;
	bHasLifespan= true;
	//replication of bullets
	bReplicates = true;
}
void AAmmoBase::BeginPlay()
{
	Super::BeginPlay();
	//muzzle flash
	if(MuzzleVfxEmitterSystem != nullptr)
	{
		MuzzleVfxEmitterComponent->Activate();
	}
	
	//adjust collision box size to match mesh
	CollisionComp->SetSphereRadius(Mesh1P->CalcBounds(Mesh1P->GetComponentTransform()).SphereRadius);
	//Adjust the mesh angle
	ANetworkChar* OwnerPlayer = Cast<ANetworkChar>(GetOwner());
	if(OwnerPlayer == nullptr)
	{
		/*if(GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1,1.0f,FColor::Red,TEXT("Failed to cast to ANetworkChar in BeginPlay."));
		}*/
		
	}
	else
	{
		
		//Set muzzle location that will be used later
	
		FVector PlayerCameraLook = OwnerPlayer->GetCamera()->GetForwardVector();
	
		PlayerCameraLook.Normalize();

		const FVector PlayerLocation = OwnerPlayer->GetActorLocation();
	
		MuzzleLocation = PlayerLocation + PlayerCameraLook * OwnerPlayer->MuzzleOffset.X;

		//Record player angle value that will be used later

		const FRotator PlayerRotation = OwnerPlayer->GetCamera()->GetComponentRotation();
	
		PlayerRotationForMuzzle = {PlayerRotation.Pitch+90,PlayerRotation.Yaw,GetActorRotation().Roll};
	}

	
}
void AAmmoBase::OnHit(UPrimitiveComponent* HitComp, AActor* OtherActor, UPrimitiveComponent* OtherComp, FVector NormalImpulse, const FHitResult& Hit)
{
	//if hit enemy AI
	AAIEnemyParent* EnemyAI = Cast<AAIEnemyParent>(OtherActor);
	if (EnemyAI)
	{
		//deal damage to enemy AI
		EnemyAI->SetCurrentHealth(DealDamage(EnemyAI->GetCurrentHealth(),Damage,EnemyAI->GetTotalHealth()));
		//prep for deletion
		if(bHasCollision)
		{
			if(HitVfxEmitterSystem!=nullptr)
			{
				HitVfxEmitterComponent->Activate();
			}
			bReadyToDie=true;
		}
	}
	
	//if hit enemy Player
	ANetworkChar* EnemyPlayer = Cast<ANetworkChar>(OtherActor);
	if (EnemyPlayer)
	{
		if(EnemyPlayer!=GetOwner())
		{
			//deal damage to enemy player
			EnemyPlayer->SetCurrentHealth(DealDamage(EnemyPlayer->GetCurrentHealth(),Damage,EnemyPlayer->GetMaxHealth()));
			//prep for deletion
			if(bHasCollision)
			{
				if(HitVfxEmitterSystem!=nullptr)
				{
					HitVfxEmitterComponent->Activate();
				}
				bReadyToDie=true;
			}
		}
		
	}
	//if hit environment
	if(OtherComp->ComponentTags.Contains("Environment"))
	{
		if(bHasCollision)
		{
			if(HitVfxEmitterSystem!=nullptr)
			{
				HitVfxEmitterComponent->Activate();
			}
			bReadyToDie=true;
		}
	}
}

void AAmmoBase::OnOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp,int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult)
{
		//if overlap enemy AI
		AAIEnemyParent* EnemyAI = Cast<AAIEnemyParent>(OtherActor);
		if (EnemyAI)
		{
			//deal damage to enemy AI
			EnemyAI->SetCurrentHealth(DealDamage(EnemyAI->GetCurrentHealth(),Damage,EnemyAI->GetTotalHealth()));
			//prep for deletion
			if(bHasCollision)
			{
				if(HitVfxEmitterSystem!=nullptr)
				{
					HitVfxEmitterComponent->Activate();
				}
				bReadyToDie=true;
			}
	
		}
		else
		{
			/*if(GEngine)
			{
				GEngine->AddOnScreenDebugMessage(-1,1.0f,FColor::Red,TEXT("Failed to cast to AAIEnemyParent in OnOverlap."));
			}*/
		}
		//if overlap enemy Player
		ANetworkChar* EnemyPlayer = Cast<ANetworkChar>(OtherActor);
		if (EnemyPlayer)
		{
			//deal damage to enemy player	
			if(EnemyPlayer!=GetInstigator())
			{
				EnemyPlayer->SetCurrentHealth(DealDamage(EnemyPlayer->GetCurrentHealth(),Damage,EnemyPlayer->GetMaxHealth()));
				//prep for deletion
				if(bHasCollision)
				{
					if(HitVfxEmitterSystem!=nullptr)
					{
						HitVfxEmitterComponent->Activate();
					}
					bReadyToDie=true;
				}
			}
		}
		else
		{
			/*if(GEngine)
			{
				GEngine->AddOnScreenDebugMessage(-1,1.0f,FColor::Red,TEXT("Failed to cast to ANetworkChar in OnOverlap."));
			}*/
		}
		//if overlap with environment
		if(OtherComp->ComponentTags.Contains("Enviroment"))

		{
			if(bHasCollision)
			{
				if(HitVfxEmitterSystem!=nullptr)
				{
					HitVfxEmitterComponent->Activate();
				}
				bReadyToDie=true;
			}
		}
	
}

void AAmmoBase::OnEndOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor,
	UPrimitiveComponent* OtherComp, int32 OtherBodyIndex)
{
}

void AAmmoBase::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
	if(bHasLifespan)
	{
		if(Lifespan<=0)
		{
			Destroy();
		}
		else
		{
			Lifespan-=DeltaTime;
		}
	}
	//Adjuct the mesh angle
	ANetworkChar* OwnerPlayer = Cast<ANetworkChar>(GetOwner());
	if(OwnerPlayer == nullptr)
	{
		/*if(GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1,1.0f,FColor::Red,TEXT("Failed to cast to ANetworkChar in Tick."));
		}*/
		return;
	}

	//Set muzzle location that will be used later
	
	FVector PlayerCameraLook = OwnerPlayer->GetCamera()->GetForwardVector();
	
	PlayerCameraLook.Normalize();

	const FVector CameraLocation = OwnerPlayer->GetCamera()->GetComponentLocation();

	
	MuzzleLocation = CameraLocation;


	//Record player angle value that will be used later

	const FRotator PlayerRotation = OwnerPlayer->GetCamera()->GetComponentRotation();
	
	PlayerRotationForMuzzle = {PlayerRotation.Pitch+90,PlayerRotation.Yaw,GetActorRotation().Roll};
	
	//checks for collision and prepares for "early" deletion
	if(bReadyToDie)
	{
		//prevents lifespan from deleting it early
		SetLifeSpan(0);
		//if the projectile does something when it collides, but before its deleted, it does it here
		if(TimeUntilDeletion<=0)
		{
			Destroy();
		}
		else
		{
			TimeUntilDeletion= TimeUntilDeletion-DeltaTime;
			if(bFades)
			{
				ProjectileVfxEmitterComponent->SetFloatParameter(FName("User.Scale"),TimeUntilDeletion);
			}
		}
	}
}

float AAmmoBase::DealDamage(const float Health, const float Damage, const float MaxHealth)
{
	//if damage would set below 0
	if(Health-Damage<=0.0)
	{
		return 0.0;
	}
	//if "damage" would set above max
	if(Health-Damage>=MaxHealth)
	{
		return MaxHealth;
	}
	//otherwise deal damage
	return Health-Damage;
}

void AAmmoBase::SetReadyToDie(bool NewValue)
{
	bReadyToDie = NewValue;
}
void AAmmoBase::SetProjectileVfx(UNiagaraSystem* Asset)
{
	ProjectileVfxEmitterSystem = Asset;
}

void AAmmoBase::SetMuzzleVfx(UNiagaraSystem* Asset)
{
	MuzzleVfxEmitterSystem = Asset;
}

void AAmmoBase::SetHitVfx(UNiagaraSystem* Asset)
{
	HitVfxEmitterSystem = Asset;
}

void AAmmoBase::SetHasLifespan(bool dies)
{
	bHasLifespan = dies;
}



