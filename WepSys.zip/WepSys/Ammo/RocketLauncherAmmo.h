// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "AmmoBase.h"
#include "PhysicsEngine/RadialForceComponent.h"

#include "RocketLauncherAmmo.generated.h"

/**
 * 
 */
UCLASS()
class BLAST_API ARocketLauncherAmmo : public AAmmoBase
{
	GENERATED_BODY()
	public:
	//unused ATM
	/**radial knock back component*/
	UPROPERTY(VisibleDefaultsOnly,BlueprintReadWrite, Category=Projectile)
	URadialForceComponent* ExplosionForce;
	/**knock back power*/
	UPROPERTY(VisibleDefaultsOnly,BlueprintReadWrite, Category=Projectile)
	float PushPower=1000.0f;
	//Radius from impact point that the damage is done
	UPROPERTY(VisibleDefaultsOnly,BlueprintReadWrite, Category=Projectile)
	float ExplosionRadius=500.0f;
	//Debug variables
	/**debug draw time*/
	float DrawDebugTime;
	/**Aoe variables/arrays*/
	TArray<TEnumAsByte<EObjectTypeQuery> > ObjectTypes;
	/**actors that dont get hit by aoe*/
	UPROPERTY(VisibleDefaultsOnly,BlueprintReadWrite,Category=Projectile)
	TArray<AActor*> ActorsToIgnore;
	/**deals Aoe damage*/
	void AoeDamage();
	/**Sets default values for this component's properties*/
	ARocketLauncherAmmo();
	/** Called when the game starts*/
	virtual void BeginPlay() override;
	/** called when projectile hits something
	* @param HitComp component that hit
	* @param OtherActor other actor that was hit
	* @param OtherComp other component that hit
	* @param NormalImpulse impulse the hit would apply
	* @param Hit hit result
	*/
	virtual void OnHit(UPrimitiveComponent* HitComp, AActor* OtherActor, UPrimitiveComponent* OtherComp, FVector NormalImpulse, const FHitResult& Hit) override;
	/** called when projectile overlaps something 
	* @param OverlappedComponent component that overlapped
	* @param OtherActor other actor that was overlapped
	* @param OtherComp other component that overlapped
	* @param OtherBodyIndex index the other object is
	* @param bFromSweep if theres a sweep
	* @param SweepResult hit result from the sweep
	*/
	virtual void OnOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult & SweepResult) override;

	
};
