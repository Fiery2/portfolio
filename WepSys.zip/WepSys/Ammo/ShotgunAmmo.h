// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "AmmoBase.h"
#include "ShotgunAmmo.generated.h"

/**
 * 
 */
UCLASS()
class BLAST_API AShotgunAmmo : public AAmmoBase
{
	GENERATED_BODY()
	protected:
	//spread variables
	/** Minimum spread in the y direction*/
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Modifiers", meta = (AllowProtectedAccess = "true"))
	float MinXSpread = -15;
	/** Minimum spread in the y direction*/
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Modifiers", meta = (AllowProtectedAccess = "true"))
	float MinYSpread = -15;
	/** Minimum spread in the z direction*/
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Modifiers", meta = (AllowProtectedAccess = "true"))
	float MinZSpread = -15;
	/** Maximum spread in the y direction*/
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Modifiers", meta = (AllowProtectedAccess = "true"))
	float MaxXSpread = 15;
	/** Maximum spread in the y direction*/
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Modifiers", meta = (AllowProtectedAccess = "true"))
	float MaxYSpread = 15;
	/** Maximum spread in the z direction*/
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Modifiers", meta = (AllowProtectedAccess = "true"))
	float MaxZSpread = 15;
	/**number of pellets in the shotgun shell*/
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Modifiers", meta = (AllowProtectedAccess = "true"))
	int32 projectilesToSpawn = 10;
	/** "bonus" projectiles */
	UPROPERTY(EditAnywhere, BlueprintReadWrite,meta = (AllowProtectedAccess = "true"))
	const TSubclassOf<AAmmoBase> Projectiles;

	/** Niagara VFX Component for splash*/
	UPROPERTY(VisibleDefaultsOnly,BlueprintReadWrite, Category=VFX)
	UNiagaraComponent* ProjectileSplashVfxEmitterComponent;
	/** Niagara VFX System used to hold the reference to the NE_ShotgunMuzzleSplash asset*/
	UPROPERTY(VisibleDefaultsOnly,BlueprintReadWrite,Category=VFX)
	UNiagaraSystem* ProjectileSplashVfxEmitterSystem;
	/**Sets default values for this component's properties*/
	AShotgunAmmo();
	/** Called when the game starts*/
	virtual void BeginPlay() override;

};
