// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"

#include "AmmoBase.h"
#include "LaserBeamAmmo.generated.h"

/**
 * 
 */
UCLASS()
class BLAST_API ALaserBeamAmmo : public AAmmoBase
{
	GENERATED_BODY()
	/**
	* called every tick, and determines the first target in line of sight
	*/
	void TraceLine();
public:
	/**Sets default values for this component's properties*/
	ALaserBeamAmmo();
	/** Called when the game starts*/
	virtual void BeginPlay() override;
	/** Called every frame*/
	virtual void Tick(float DeltaTime) override;
	/** called when projectile overlaps something 
	* @param OverlappedComponent component that overlapped
	* @param OtherActor other actor that was overlapped
	* @param OtherComp other component that overlapped
	* @param OtherBodyIndex index the other object is
	* @param bFromSweep if theres a sweep
	* @param SweepResult hit result from the sweep
	*/
	virtual void OnOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult & SweepResult) override;
	/** called when projectile stops overlaping something 
	* @param OverlappedComponent component that overlapped
	* @param OtherActor other actor that was overlapped
	* @param OtherComp other component that overlapped
	* @param OtherBodyIndex index the other object is
	*/
	virtual void OnEndOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex) override;
	
};
