﻿#include "FlameThrowerHitBox.h"
#include "AIEnemyParent.h"
#include "NetworkChar.h"
#include "BehaviorTree/BehaviorTreeTypes.h"
#include "GameFrameWork/ProjectileMovementComponent.h"
#include "DrawDebugHelpers.h"

AFlameThrowerHitBox::AFlameThrowerHitBox()
{
	/**Set up the Tick function*/
	PrimaryActorTick.bCanEverTick = true;

	/**General Value initialization*/
	DamageValue = 1.0f;
	Speed = 1000;
	bHasHit = false;

	/**Set up the Collision box*/
	if(!CollisionMesh)
	{
		CollisionMesh = CreateDefaultSubobject<UBoxComponent>(FName("Collision Mesh"));
		CollisionMesh->BodyInstance.SetCollisionProfileName("Projectile");
		CollisionMesh->IgnoreActorWhenMoving(GetInstigator(),true);
		CollisionMesh->SetEnableGravity(false);
		CollisionMesh->SetSimulatePhysics(false);
		CollisionMesh->CanCharacterStepUpOn = ECB_No;
		CollisionMesh->ComponentTags.Add("projectile");
		SetRootComponent(CollisionMesh);
		CollisionMesh->OnComponentBeginOverlap.AddDynamic(this,&AFlameThrowerHitBox::OnOverlap);
	}
	
	
	/**Use a ProjectileMovementComponent to govern this projectile's movement*/
	if (!ProjectileMovement)
	{
    	ProjectileMovement = CreateDefaultSubobject<UProjectileMovementComponent>(TEXT("ProjectileComp"));
    	ProjectileMovement->SetUpdatedComponent(CollisionMesh);
    	ProjectileMovement->InitialSpeed = Speed;
    	ProjectileMovement->MaxSpeed = Speed;
    	ProjectileMovement->bRotationFollowsVelocity = true;
    	ProjectileMovement->bShouldBounce = false;
    	ProjectileMovement->Bounciness=0;
    	ProjectileMovement->ProjectileGravityScale = 0;
    	ProjectileMovement->bUpdateOnlyIfRendered=false;
    }
	
}

void AFlameThrowerHitBox::BeginPlay()
{
	AActor::BeginPlay();

	/**Empty for now, may need for things that cannot be done in the constructor*/
}


void AFlameThrowerHitBox::Tick(float DeltaSeconds)
{
	Super::Tick(DeltaSeconds);

	/**Count down the lifetime*/
	LifeTime -= DeltaSeconds;

	/**Destroy this instance when lifetime is less than or equal to 0.0.
	 * @Note : Destroy() should free up memory. We have had memory leak issues and I am trying to narrow down the issue.
	 */
	if(LifeTime <= 0.0)
	{
		Destroy();
	}
}

bool AFlameThrowerHitBox::GetHasHit() const
{
	return bHasHit;
}

void AFlameThrowerHitBox::SetTimer(const float NewTime)
{
	LifeTime = NewTime;
}

void AFlameThrowerHitBox::OnOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor,
                                    UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult)
{
		/**If overlap enemy Player or AI*/
		AAIEnemyParent* EnemyAI = Cast<AAIEnemyParent>(OtherActor);
		ANetworkChar* EnemyPlayer = Cast<ANetworkChar>(OtherActor);
		if(EnemyAI || EnemyPlayer)
		{
			bHasHit = true;
			SetTimer(0.5f);
		}

		if(EnemyPlayer)
		{
			/**Check if the collisded actor is not the shooter*/
			if(EnemyPlayer != GetOwner())
			{
				// deal our damage and set our status effect
				EnemyPlayer->DealDamageToPlayer(DamageValue);
				EnemyPlayer->SetPlayerStatusEffect(ANetworkChar::FIRE);
			}
		}
		else if(EnemyAI)
		{
			// deal our damage and set the fire effect
			EnemyAI->SetCurrentHealth(EnemyAI->GetCurrentHealth()-DamageValue);
			EnemyAI->SetEnemyStatusEffect(AAIEnemyParent::FIRE);
		}
}
