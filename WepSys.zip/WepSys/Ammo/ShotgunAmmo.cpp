// Fill out your copyright notice in the Description page of Project Settings.


#include "ShotgunAmmo.h"

#include "Components/SphereComponent.h"
#include "GameFramework/ProjectileMovementComponent.h"
#include "WepSys/Wep/Husk.h"
#define COLLISION_PROJECTILE	ECC_GameTraceChannel1

AShotgunAmmo::AShotgunAmmo() : AAmmoBase()
{
	//set mesh and collision stuff
	static ConstructorHelpers::FObjectFinder<UStaticMesh>MeshAsset(TEXT("StaticMesh'/Game/BLAST/Gameplay/WepSys/Sphere.Sphere'"));
	UStaticMesh* Asset = MeshAsset.Object;
	Mesh1P->SetStaticMesh(Asset);
	CollisionComp->InitSphereRadius(Mesh1P->CalcBounds(Mesh1P->GetComponentTransform()).SphereRadius);
	
	//setup niagara details
	static ConstructorHelpers::FObjectFinder<UNiagaraSystem>NiagaraAsset(TEXT("NiagaraSystem'/Game/BLAST/FX/NES/NE_Shotgun_Trails.NE_Shotgun_Trails'"));
	ProjectileVfxEmitterSystem= NiagaraAsset.Object;
	ProjectileVfxEmitterComponent->SetAsset(ProjectileVfxEmitterSystem);
	if(!ProjectileSplashVfxEmitterComponent)
	{
		ProjectileSplashVfxEmitterComponent = CreateDefaultSubobject<UNiagaraComponent>(TEXT("ProjectileSplashNiagaraComponent"));
		ProjectileSplashVfxEmitterComponent->SetupAttachment(RootComponent);
		ProjectileSplashVfxEmitterComponent->ComponentTags.Add("projectile");
		ProjectileSplashVfxEmitterComponent->Deactivate();
		static ConstructorHelpers::FObjectFinder<UNiagaraSystem>NiagaraSplashAsset(TEXT("NiagaraSystem'/Game/BLAST/FX/NES/NE_ShotgunMuzzleSplash.NE_ShotgunMuzzleSplash'"));
		ProjectileSplashVfxEmitterSystem = NiagaraSplashAsset.Object;
		ProjectileSplashVfxEmitterComponent->SetAsset(ProjectileSplashVfxEmitterSystem);
	}
	static ConstructorHelpers::FObjectFinder<UNiagaraSystem>NiagaraAsset2(TEXT("NiagaraSystem'/Game/BLAST/FX/NES/NE_ShotgunMuzzleFlash.NE_ShotgunMuzzleFlash'"));
	MuzzleVfxEmitterSystem = NiagaraAsset2.Object;
	MuzzleVfxEmitterComponent->SetAsset(MuzzleVfxEmitterSystem);
	HitVfxEmitterSystem = nullptr;
	HitVfxEmitterComponent->SetAsset(HitVfxEmitterSystem);
	//set AmmoUnique variables
	Damage = 10;
	AmmoCount=20;
	Lifespan = 0.5f;
	bHasLifespan = true;
	AmmoFireTime=0.2;
	//replication of bullets
	bReplicates = true;
}
void AShotgunAmmo::BeginPlay()
{
	Super::BeginPlay();
	//spawn Splash VFX if it has it
	if(ProjectileSplashVfxEmitterSystem != nullptr)
	{
		ProjectileSplashVfxEmitterComponent->Activate();
	}
	//scale main projectile
	this->Mesh1P->SetRelativeScale3D(FVector(0.02,0.02,0.02));
	//dont show mesh
	this->Mesh1P->SetVisibility(true);
	//spawn "bonus" projectiles
	for(int i = 0; i<projectilesToSpawn; i++)
	{
		
		UWorld* const World = GetWorld();
		//addRotation
		FActorSpawnParameters ActorSpawnParams;
		ActorSpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AdjustIfPossibleButDontSpawnIfColliding;
		ActorSpawnParams.Owner = GetOwner();
		ActorSpawnParams.Instigator = GetInstigator();
		float x=FMath::RandRange(MinXSpread,MaxXSpread);
		float y=FMath::RandRange(MinYSpread,MaxYSpread);
		float z=FMath::RandRange(MinZSpread,MaxZSpread);
		FVector spread = FVector( x, y,z );
		
		AAmmoBase* newProjectile = World->SpawnActor<AAmmoBase>(AAmmoBase::StaticClass(), this->GetActorLocation()+spread, this->GetActorRotation(), ActorSpawnParams);
		newProjectile->ProjectileVfxEmitterComponent->SetAsset(ProjectileVfxEmitterSystem);
		newProjectile->MuzzleVfxEmitterComponent->Deactivate();
		newProjectile->HitVfxEmitterComponent->Deactivate();
		newProjectile->Mesh1P->SetRelativeScale3D(FVector(0.02,0.02,0.02));
		newProjectile->Damage = 10;
		newProjectile->Lifespan = 0.5f;
		newProjectile->bHasLifespan = true;
		newProjectile->CollisionComp->InitSphereRadius(Mesh1P->CalcBounds(Mesh1P->GetComponentTransform()).SphereRadius);
	}

}


