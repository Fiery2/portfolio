﻿#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "DrawDebugHelpers.h"
#include "NiagaraComponent.h"
#include "Components/TimelineComponent.h"
#include "GameFramework/Character.h"
//#include "BLAST/FPCharacter.h"
#include "AmmoBase.generated.h"

class USphereComponent;
class UProjectileMovementComponent;
class UStaticMeshComponent;
/*
*This is the base for all Projectiles, altering this file will change all other Projectile specs 
*/
UCLASS(config=Game)
class BLAST_API AAmmoBase : public AActor
{
	GENERATED_BODY()
	
	public:

	/** The max range that the laser can fire  */ //1000 should be replaced with map bounds
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Ammo Type Settings | Laser Settings", meta = (AllowProtectedAccess = "true"))
	int MaxLaserRange = 1000;
	
	/** Sphere collision component */
	UPROPERTY(VisibleDefaultsOnly,BlueprintReadWrite, Category=Projectile)
	USphereComponent* CollisionComp;
	/** Projectile movement component */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Movement, meta = (AllowPrivateAccess = "true"))
	UProjectileMovementComponent* ProjectileMovement;
	/** Mesh component*/
	UPROPERTY(EditAnywhere,BlueprintReadWrite, Category=Mesh)
	UStaticMeshComponent* Mesh1P;
	/** Niagara VFX Component*/
	UPROPERTY(VisibleDefaultsOnly,BlueprintReadWrite, Category=VFX)
	UNiagaraComponent* ProjectileVfxEmitterComponent;
	/** Niagara VFX System used to hold the reference to the NE_Projectile_... assets*/
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category=VFX)
	UNiagaraSystem* ProjectileVfxEmitterSystem;
	/** Niagara VFX Component Played on spawn*/
	UPROPERTY(VisibleDefaultsOnly,BlueprintReadWrite, Category=VFX)
	UNiagaraComponent* MuzzleVfxEmitterComponent;
	/** Niagara VFX System used to hold the reference to the NE_Muzzle_... assets*/
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category=VFX)
	UNiagaraSystem* MuzzleVfxEmitterSystem;
	/** Niagara VFX Component Played on death*/
	UPROPERTY(VisibleDefaultsOnly,BlueprintReadWrite, Category=VFX)
	UNiagaraComponent* HitVfxEmitterComponent;
	/** Niagara VFX System used to hold the reference to the NE_Hit_... assets*/
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category=VFX)
	UNiagaraSystem* HitVfxEmitterSystem;

	/**Sets default values for this component's properties*/
	AAmmoBase();
	//Death checker variables
	/**has collided with something*/
	UPROPERTY(EditAnywhere,BlueprintReadWrite, Category=DeathVars, meta = (AllowPrivateAccess = "true"))
	bool bReadyToDie = false;
	/**has collision*/
	UPROPERTY(EditAnywhere,BlueprintReadWrite, Category=DeathVars, meta = (AllowPrivateAccess = "true"))
	bool bHasCollision = true;
	/**
	 *timer allowing for collision effects before deleting the projectile
	 * set by ammo if needed
	 */
	UPROPERTY(EditAnywhere,BlueprintReadWrite, Category=DeathVars, meta = (AllowPrivateAccess = "true"))
	float TimeUntilDeletion=0.0;
	/**whether or not the ammo fades when it dies*/
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category=VFX)
	/**if it needs a fade effect*/
	bool bFades = false;

	/**
	 *The Muzzle Location to be used by all ammo types
	 */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category=Projectile,meta = (AllowPrivateAccess = "true"))
	FVector MuzzleLocation;

	/**
	 *The Angle of the camera to be used by all ammo types
	 */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category=Projectile,meta = (AllowPrivateAccess = "true"))
	FRotator PlayerRotationForMuzzle;

	
//all variables below should be unique to each ammo type
	
	/**how much damage the projectile does*/
	UPROPERTY(EditAnywhere,BlueprintReadWrite, Category=AmmoUnique, meta = (AllowPrivateAccess = "true"))
	float Damage;
	/**how long far the projectile can go*/
	UPROPERTY(EditAnywhere,BlueprintReadWrite, Category=AmmoUnique, meta = (AllowPrivateAccess = "true"))
	float Lifespan=1.0f;
	/**if the projectile can de-spawn*/
	UPROPERTY(EditAnywhere,BlueprintReadWrite, Category=AmmoUnique, meta = (AllowPrivateAccess = "true"))
	bool bHasLifespan=true;
	/** the amount of time the player can fire the ammo  */ 
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = AmmoUnique, meta = (AllowProtectedAccess = "true"))
	int AmmoCount;
	/**Either the fire rate variable or the charge time variable, depending on the ammo type*/
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = AmmoUnique, meta = (AllowProtectedAccess = "true"))
	float AmmoFireTime;
	/**is it the instince that is used for variable access*/
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = AmmoUnique, meta = (AllowProtectedAccess = "true"))
	bool bIsInstance=false;
	/**
	 *array of all enemies in line of fire
	 * only used by HoldFireType 2
	 */
	UPROPERTY(EditDefaultsOnly,BlueprintReadWrite,Category=AmmoUnique)
	TArray<AActor*> AffectedEnemies;

	
	/** called when projectile hits something
	 * @param HitComp component that hit
	 * @param OtherActor other actor that was hit
	 * @param OtherComp other component that hit
	 * @param NormalImpulse impulse the hit would apply
	 * @param Hit hit result
	 */
	UFUNCTION()
	virtual void OnHit(UPrimitiveComponent* HitComp, AActor* OtherActor, UPrimitiveComponent* OtherComp, FVector NormalImpulse, const FHitResult& Hit);
	/** called when projectile overlaps something 
	* @param OverlappedComponent component that overlapped
	* @param OtherActor other actor that was overlapped
	* @param OtherComp other component that overlapped
	* @param OtherBodyIndex index the other object is
	* @param bFromSweep if theres a sweep
	* @param SweepResult hit result from the sweep
	*/
	UFUNCTION()
	virtual void OnOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult & SweepResult);
	/** called when projectile stops overlaping something 
	* @param OverlappedComponent component that overlapped
	* @param OtherActor other actor that was overlapped
	* @param OtherComp other component that overlapped
	* @param OtherBodyIndex index the other object is
	*/
	UFUNCTION()
	virtual void OnEndOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex);
	protected:
	/** Called when the game starts*/
	virtual void BeginPlay() override;
	public:
	/** Called every frame*/
	virtual void Tick(float DeltaTime) override;
	/**
	 * deals damage to the health variable of the collided object
	 * @param Health current health of the object 
	 * @param Damage  amount of damage being done 
	 * @param MaxHealth max health of the object
	 * @return new health of the object
	 */
	static float DealDamage(float Health,float Damage,float MaxHealth);

	/**
	 *Setter for the bReadyToDie bool
	 *This will be used primarily for the flamethrower ammo or anything that needs time before the destroy call
	 *that would not fit in the default ending functions and deconstructors.
	 */
	UFUNCTION()
	void SetReadyToDie(bool NewValue);
	/**
	*Setter for the VFX 
	*is needed for artists to use
	*/
	UFUNCTION(BlueprintCallable)
	void SetProjectileVfx (UNiagaraSystem* Asset);
	/**
	*Setter for the VFX 
	*is needed for artists to use
	*/
	UFUNCTION(BlueprintCallable)
	void SetMuzzleVfx (UNiagaraSystem* Asset);
	/**
	*Setter for the VFX 
	*is needed for artists to use
	*/
	UFUNCTION(BlueprintCallable)
	void SetHitVfx (UNiagaraSystem* Asset);
	/**
	*Setter for bHasLifespan
	*/
	UFUNCTION(BlueprintCallable)
	void SetHasLifespan (bool dies);
};

