﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "ChargeLaserAmmo.h"
#include "FlamethrowerAmmo.h"
#include "LaserBeamAmmo.h"
#include "RocketLauncherAmmo.h"
#include "ShotgunAmmo.h"
#include "EPickupNames.h"

#include "Components/ActorComponent.h"
#include "Husk.generated.h"
/*
 * This component is basically the gun itself
 * it contains all thing used to spawn and alter projectiles
 */


class AAmmoBase;
UCLASS( ClassGroup=(Custom), meta=(BlueprintSpawnableComponent) )
class BLAST_API UHusk : public UActorComponent
{
	GENERATED_BODY()

protected:
	/**Mesh of the gun*/
	UPROPERTY(VisibleDefaultsOnly,BlueprintReadOnly, Category=gun)
	UStaticMeshComponent* GunMesh;
	/**blueprint-set reference to base ammo , to access its variables  */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category=AmmoVars,meta = (AllowProtectedAccess = "true"))
	TSubclassOf<AAmmoBase> AmmoBaseInstance;
	/**blueprint-set reference to shotygun ammo , to access its variables  */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category=AmmoVars,meta = (AllowProtectedAccess = "true"))
	TSubclassOf<AShotgunAmmo> ShotgunAmmoInstance;
	/**blueprint-set reference to RocketLauncher ammo , to access its variables  */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category=AmmoVars,meta = (AllowProtectedAccess = "true"))
	TSubclassOf<ARocketLauncherAmmo> RocketLauncherAmmoInstance;
	/**blueprint-set reference to Rail gun ammo , to access its variables  */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category=AmmoVars,meta = (AllowProtectedAccess = "true"))
	TSubclassOf<AChargeLaserAmmo> RailGunAmmoInstance;
	/**blueprint-set reference to Flamethrower ammo , to access its variables  */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category=AmmoVars,meta = (AllowProtectedAccess = "true"))
	TSubclassOf<AFlamethrowerAmmo> FlamethrowerAmmoInstance;
	/**blueprint-set reference to Laser Beam ammo , to access its variables  */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category=AmmoVars, meta = (AllowProtectedAccess = "true"))
	TSubclassOf<ALaserBeamAmmo> LaserBeamAmmoInstance;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category=AmmoVars,meta = (AllowProtectedAccess = "true"))
	AAmmoBase* BaseAmmoInstanceProjectile;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category=AmmoVars,meta = (AllowProtectedAccess = "true"))
	AAmmoBase* ShotgunAmmoInstanceProjectile;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category=AmmoVars,meta = (AllowProtectedAccess = "true"))
	AAmmoBase* RocketLauncherAmmoInstanceProjectile;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category=AmmoVars,meta = (AllowProtectedAccess = "true"))
	AAmmoBase* RailGunAmmoInstanceProjectile;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category=AmmoVars,meta = (AllowProtectedAccess = "true"))
	AAmmoBase* FlamethrowerAmmoInstanceProjectile;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category=AmmoVars,meta = (AllowProtectedAccess = "true"))
	AAmmoBase* LaserBeamAmmoInstanceProjectile;

	/**Sets default values for this component's properties*/
	UHusk();
	/**spawned projectile*/
	UPROPERTY(EditDefaultsOnly,Category=AmmoVars)
	AAmmoBase* Projectile;
	/**spawned DamageOverTime projectile*/
	UPROPERTY(EditDefaultsOnly,Category=AmmoVars)
	AAmmoBase* DamageOverTimeProjectile;
	/**Ammo one PickupName */
	UPROPERTY(EditAnywhere,BlueprintReadWrite, Category=AmmoVars,meta = (AllowProtectedAccess = "true"))
	TEnumAsByte<EPickupNames> AmmoOneState;
	/**Ammo Two PickupNames */
	UPROPERTY(EditAnywhere,BlueprintReadWrite, Category=AmmoVars,meta = (AllowProtectedAccess = "true"))
	TEnumAsByte<EPickupNames> AmmoTwoState;
	/**Default Ammo PickupNames */
	UPROPERTY(EditAnywhere,BlueprintReadWrite, Category=AmmoVars,meta = (AllowProtectedAccess = "true"))
	TEnumAsByte<EPickupNames> DefaultAmmoState;
	/**Ammo slot one */
	UPROPERTY(EditAnywhere,BlueprintReadWrite, Category=AmmoVars)
	TSubclassOf<AAmmoBase> AmmoOne=nullptr;
	/**Ammo slot two */
	UPROPERTY(EditAnywhere,BlueprintReadWrite, Category=AmmoVars)
	TSubclassOf<class AAmmoBase> AmmoTwo=nullptr;
	/**Ammo used if nothing in either ammo slot */
	UPROPERTY(EditAnywhere,BlueprintReadWrite, Category=AmmoVars)
	TSubclassOf<class AAmmoBase> DefaultAmmo;
	/**number of non-default ammo in slot one */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category=AmmoVars)
	int32 AmmoOneCount;
	/**number of non-default ammo in slot two */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category=AmmoVars)
	int32 AmmoTwoCount;
	/**The time required to charge/ROF before shooting for AmmoOne */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category=AmmoVars)
	float AmmoOneChargeTime;
	/**The time required to charge/ROF before shooting for AmmoTwo */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category=AmmoVars)
	float AmmoTwoChargeTime;
	/**The time required to charge/ROF before shooting for DefaultAmmo */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category=AmmoVars)
	float DefaultAmmoChargeTime = 0.1f;
	/**The max time required to charge/ROF before shooting for AmmoOne */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category=AmmoVars)
	float AmmoOneMaxChargeTime;
	/**The max time required to charge/ROF before shooting for AmmoTwo */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category=AmmoVars)
	float AmmoTwoMaxChargeTime;
	/**The max time required to charge/ROF before shooting for DefaultAmmo */
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category=AmmoVars)
	float DefaultAmmoMaxChargeTime = 0.1f;
	/**The ammo slot that is used when fireing 
	*0 default
	*1 Slot 1
	*2 Slot 2
	*/
	UPROPERTY(EditAnywhere,BlueprintReadWrite,Category=AmmoVars)
	int ActiveAmmoSlot;
	/**if the fire button is down*/
	bool bIsFireButtonHeld=false;
	/**if the shot has a fire rate and is on cooldown*/
	UPROPERTY(EditAnywhere,BlueprintReadWrite, Category=AmmoVars,meta = (AllowProtectedAccess = "true"))
	bool bOnCooldown=false;
	/** Called when the game starts*/
	virtual void BeginPlay() override;

public:	
	/** Called every frame*/
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;
	/**
	* spawns a projectile and decrements the ammo count
	* @param SpawnLocation - used for the SpawnActor function
	* @param SpawnRotation - used for the SpawnActor function
	* @param World - used for the SpawnActor function
	* @param ActorSpawnParams - used for the SpawnActor function
	*/
	virtual void Fire(FVector SpawnLocation,FRotator SpawnRotation, UWorld* const World,FActorSpawnParameters ActorSpawnParams);
	/**
	* spawns a projectile and decrements the ammo count
	* @param SpawnLocation - used for the SpawnActor function
	* @param SpawnRotation - used for the SpawnActor function
	* @param World - used for the SpawnActor function
	* @param ActorSpawnParams - used for the SpawnActor function
	*/
	void ReleaseFire(FVector SpawnLocation,FRotator SpawnRotation, UWorld* const World,FActorSpawnParameters ActorSpawnParams);
	/**
	 *Checks if active ammo "mag" is empty
	 */
	void CheckIfActiveAmmoIsEmpty();
	/**
	* "loads" a new ammo into the gun
	* @param NewGunAmmoName - ammo type that just got picked up
	* @return if succesful
	*/
	UFUNCTION(BlueprintCallable, Category=FunctionVars)
	bool SetGunAmmo(EPickupNames NewGunAmmoName );
	/**
	* sets active ammo
	*/
	void AmmoSwitcher();
	/**
	 * Sets weapon to spawning state
	 */
	void ResetWeapon();
//getters and setters that get/set their respective variables
	
	//getters and setters that use EPickupNames to get/set their respective variables
	/**
	 * sets the Ammo slot given to The ammo specified by the State given
	 * @param AmmoSlot Either AmmoOne, AmmoTwo, or DefaultAmmo
	 * @param AmmoSlotState Either  AmmoOneState, AmmoTwoState, or DefaultAmmoState
	 * @Note the AmmoSlot and AmmoSlotState should match
	 */
	TSubclassOf<AAmmoBase> GetAmmoInstance(EPickupNames AmmoSlotState);
	/**
	* sets the Ammo slot given to The ammo specified by the State given
	* @param AmmoSlot Either AmmoOne, AmmoTwo, or DefaultAmmo
	* @param AmmoSlotState Either  AmmoOneState, AmmoTwoState, or DefaultAmmoState
	* @Note the AmmoSlot and AmmoSlotState should match
	* @return instance of that ammo
	*/
	AAmmoBase* GetAmmoInstanceProjectile(EPickupNames AmmoSlotState);
	//----------------------------
	/**
	* Gets the bActiveAmmo variable
	*/
	UFUNCTION(BlueprintCallable, Category=Getter)
	int GetActiveAmmoSlot();
	/**
	* Gets the bActiveAmmo variable
	*/
	UFUNCTION(BlueprintCallable, Category=Getter)
	EPickupNames GetActiveAmmoState();
	/**
	* Sets Active ammo 
	*/
	UFUNCTION(BlueprintCallable, Category=Setter)
	void SetActiveAmmoState(EPickupNames NewAmmo);
	/**
	* Gets Active ammo 
	*/
	UFUNCTION(BlueprintCallable, Category=Getter)
	TSubclassOf<AAmmoBase> GetActiveAmmo();
	/**
	* Gets Active ammo  name
	*/
	UFUNCTION(BlueprintCallable, Category=Getter)
	FString GetActiveAmmoName();
	/**
	* Gets inActive ammo 
	*/
	UFUNCTION(BlueprintCallable, Category=Getter)
	TSubclassOf<AAmmoBase> GetInActiveAmmo();
	/**
	* Sets Active ammo 
	*/
	UFUNCTION(BlueprintCallable, Category=Setter)
	void SetActiveAmmo(TSubclassOf<AAmmoBase> NewAmmo);
	/**
	* Sets INActive ammo 
	*/
	UFUNCTION(BlueprintCallable, Category=Setter)
	void SetInActiveAmmo(TSubclassOf<AAmmoBase> NewAmmo);
	/**
	* Gets Active ammo count
	*/
	UFUNCTION(BlueprintCallable, Category=Getter)
	int GetActiveAmmoCount();
	/**
	* sets Active ammo count
	*/
	UFUNCTION(BlueprintCallable, Category=Getter)
	void SetActiveAmmoCount(int NewCount);
	/**
	* Gets Active ammo's chargeTime 
	*/
	UFUNCTION(BlueprintCallable, Category=Getter)
	float GetActiveAmmoChargeTime();
	/**
	* sets Active ammo's chargeTime 
	*/
	UFUNCTION(BlueprintCallable, Category=Setter)
	void SetActiveAmmoChargeTime(float NewChargeTime);
	/**
	* Gets Active ammo's max chargeTime 
	*/
	UFUNCTION(BlueprintCallable, Category=Getter)
	float GetActiveAmmoMaxChargeTime();
	/**
	* Gets is holding count
	*/
	UFUNCTION(BlueprintCallable, Category=Getter)
	bool IsHolding();
	//----------------------------
	/**
	* Gets specified ammo name
	* @param AmmoSlotNumber slot number of ammo name that is being gotten
	* @return  requested Ammo name
	*/
	UFUNCTION(BlueprintCallable, Category=Getter)
	FString GetSpecificAmmoName(int AmmoSlotNumber);
	/**
	* Gets specified ammo count
	* @param AmmoSlotNumber slot number of ammo count that is being gotten
	* @return requested Ammo count
	*/
	UFUNCTION(BlueprintCallable, Category=Getter)
	int GetSpecificAmmoCount(int AmmoSlotNumber);
	/**
	* Sets specified ammo count
	* @param NewCount new ammo count
	* @param AmmoSlotNumber slot number of ammo count that is being updated
	*/
	UFUNCTION(BlueprintCallable, Category=Setter)
	void SetSpecificAmmoCount(int NewCount,int AmmoSlotNumber);

	

};
