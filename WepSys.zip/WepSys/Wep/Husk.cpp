﻿
// Fill out your copyright notice in the Description page of Project Settings.


#include "Husk.h"
#include "AmmoBase.h"

#include "Kismet/GameplayStatics.h"



//Sets default values for this component's properties
UHusk::UHusk()
{
	
	PrimaryComponentTick.bCanEverTick = true;
	/**set the gun mesh*/
	GunMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("FP_Gun"));
	GunMesh->SetOnlyOwnerSee(false);			// otherwise won't be visible in the multiplayer
	GunMesh->bCastDynamicShadow = false;
	GunMesh->CastShadow = false;
	/**set the default ammo counts*/
	AmmoOneCount = 0;
	AmmoTwoCount = 0;
	AmmoOneState = PNone;
	AmmoTwoState = PNone;
	DefaultAmmoState =PDefault;
	/**sets up the ammocheckers to the default state*/
    ActiveAmmoSlot=0;
	//DefaultAmmo = AAmmoBase::StaticClass();
	/*AAmmoBase* DefaultAmmoCast = Cast<AAmmoBase>(GetAmmoInstance(DefaultAmmoState));
	DefaultAmmoCast = CreateDefaultSubobject<AAmmoBase>(TEXT("default"));
	DefaultAmmoChargeTime = DefaultAmmoCast->AmmoFireTime;
	DefaultAmmoMaxChargeTime = DefaultAmmoCast->AmmoFireTime;*/

}


void UHusk::BeginPlay()
{
	Super::BeginPlay();
	// create projectiles that we will access to get the variables they contain
	UWorld* const World = GetWorld();
	FActorSpawnParameters ActorSpawnParams;
	ActorSpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AdjustIfPossibleButDontSpawnIfColliding;
	ActorSpawnParams.Owner = GetOwner();
	FVector InstanceLocation = FVector(0,0,-300);
	FRotator InstanceRotator = FRotator(0,0,0);
	BaseAmmoInstanceProjectile= World->SpawnActor<AAmmoBase>(AmmoBaseInstance,InstanceLocation,InstanceRotator,ActorSpawnParams );
	if(BaseAmmoInstanceProjectile)
	{
		BaseAmmoInstanceProjectile->SetHasLifespan(false);
		BaseAmmoInstanceProjectile->bIsInstance = true;
		BaseAmmoInstanceProjectile->ProjectileMovement->Deactivate();
		BaseAmmoInstanceProjectile->ProjectileVfxEmitterComponent->Deactivate();
		BaseAmmoInstanceProjectile->MuzzleVfxEmitterComponent->Deactivate();
		BaseAmmoInstanceProjectile->HitVfxEmitterComponent->Deactivate();
		BaseAmmoInstanceProjectile->CollisionComp->Deactivate();
		BaseAmmoInstanceProjectile->SetReplicates(true);
	}
	ShotgunAmmoInstanceProjectile= World->SpawnActor<AAmmoBase>(ShotgunAmmoInstance,InstanceLocation,InstanceRotator,ActorSpawnParams );
	if(ShotgunAmmoInstanceProjectile)
	{
		ShotgunAmmoInstanceProjectile->SetHasLifespan(false);
		ShotgunAmmoInstanceProjectile->bIsInstance = true;
		ShotgunAmmoInstanceProjectile->ProjectileMovement->Deactivate();
		ShotgunAmmoInstanceProjectile->ProjectileVfxEmitterComponent->Deactivate();
		ShotgunAmmoInstanceProjectile->MuzzleVfxEmitterComponent->Deactivate();
		ShotgunAmmoInstanceProjectile->HitVfxEmitterComponent->Deactivate();
		ShotgunAmmoInstanceProjectile->CollisionComp->Deactivate();
		ShotgunAmmoInstanceProjectile->SetReplicates(true);
	}
	RocketLauncherAmmoInstanceProjectile= World->SpawnActor<AAmmoBase>(RocketLauncherAmmoInstance,InstanceLocation,InstanceRotator,ActorSpawnParams );
	if(RocketLauncherAmmoInstanceProjectile)
	{
		RocketLauncherAmmoInstanceProjectile->SetHasLifespan(false);
		RocketLauncherAmmoInstanceProjectile->bIsInstance = true;
		RocketLauncherAmmoInstanceProjectile->ProjectileMovement->Deactivate();
		RocketLauncherAmmoInstanceProjectile->ProjectileVfxEmitterComponent->Deactivate();
		RocketLauncherAmmoInstanceProjectile->MuzzleVfxEmitterComponent->Deactivate();
		RocketLauncherAmmoInstanceProjectile->HitVfxEmitterComponent->Deactivate();
		RocketLauncherAmmoInstanceProjectile->CollisionComp->Deactivate();
		RocketLauncherAmmoInstanceProjectile->SetReplicates(true);
	}
	
	RailGunAmmoInstanceProjectile= World->SpawnActor<AAmmoBase>(RailGunAmmoInstance,InstanceLocation,InstanceRotator,ActorSpawnParams );
	if(RailGunAmmoInstanceProjectile)
	{
		RailGunAmmoInstanceProjectile->SetHasLifespan(false);
		RailGunAmmoInstanceProjectile->bIsInstance = true;
		RailGunAmmoInstanceProjectile->ProjectileMovement->Deactivate();
		RailGunAmmoInstanceProjectile->ProjectileVfxEmitterComponent->Deactivate();
		RailGunAmmoInstanceProjectile->MuzzleVfxEmitterComponent->Deactivate();
		RailGunAmmoInstanceProjectile->HitVfxEmitterComponent->Deactivate();
		RailGunAmmoInstanceProjectile->CollisionComp->Deactivate();
		RailGunAmmoInstanceProjectile->SetReplicates(true);
	}
	/*FlamethrowerAmmoInstanceProjectile= World->SpawnActor<AAmmoBase>(FlamethrowerAmmoInstance,InstanceLocation,InstanceRotator,ActorSpawnParams );
	if(FlamethrowerAmmoInstanceProjectile)
	{
		FlamethrowerAmmoInstanceProjectile->MuzzleLocation = InstanceLocation;
		FlamethrowerAmmoInstanceProjectile->SetHasLifespan(false);
		FlamethrowerAmmoInstanceProjectile->bIsInstance = true;
		FlamethrowerAmmoInstanceProjectile->ProjectileMovement->Deactivate();
		FlamethrowerAmmoInstanceProjectile->ProjectileVfxEmitterComponent->Deactivate();
		FlamethrowerAmmoInstanceProjectile->MuzzleVfxEmitterComponent->Deactivate();
		FlamethrowerAmmoInstanceProjectile->HitVfxEmitterComponent->Deactivate();
		FlamethrowerAmmoInstanceProjectile->CollisionComp->Deactivate();
		FlamethrowerAmmoInstanceProjectile->SetReplicates(true);
	}
	LaserBeamAmmoInstanceProjectile= World->SpawnActor<AAmmoBase>(LaserBeamAmmoInstance,InstanceLocation,InstanceRotator,ActorSpawnParams );
	if(LaserBeamAmmoInstanceProjectile)
	{
		LaserBeamAmmoInstanceProjectile->MuzzleLocation = InstanceLocation;
		LaserBeamAmmoInstanceProjectile->SetHasLifespan(false);
		LaserBeamAmmoInstanceProjectile->bIsInstance = true;
		LaserBeamAmmoInstanceProjectile->ProjectileMovement->Deactivate();
		LaserBeamAmmoInstanceProjectile->ProjectileVfxEmitterComponent->Deactivate();
		LaserBeamAmmoInstanceProjectile->MuzzleVfxEmitterComponent->Deactivate();
		LaserBeamAmmoInstanceProjectile->HitVfxEmitterComponent->Deactivate();
		LaserBeamAmmoInstanceProjectile->CollisionComp->Deactivate();
		LaserBeamAmmoInstanceProjectile->SetReplicates(true);
	}*/

	
	// set default ammo
	DefaultAmmo = GetAmmoInstance(DefaultAmmoState);
	AAmmoBase* DefaultAmmoCast = GetAmmoInstanceProjectile(DefaultAmmoState);
	DefaultAmmoChargeTime = DefaultAmmoCast->AmmoFireTime;
	DefaultAmmoMaxChargeTime = DefaultAmmoCast->AmmoFireTime;
		
	
}


void UHusk::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);
	//if the fire button is held
	/*FVector InstanceLocation = FVector(0,0,-300);
	if(LaserBeamAmmoInstanceProjectile)
	{
		LaserBeamAmmoInstanceProjectile->MuzzleLocation = InstanceLocation;
		LaserBeamAmmoInstanceProjectile->SetActorLocation(InstanceLocation);
	}
	if(FlamethrowerAmmoInstanceProjectile)
	{
		FlamethrowerAmmoInstanceProjectile->MuzzleLocation = InstanceLocation;
		FlamethrowerAmmoInstanceProjectile->SetActorLocation(InstanceLocation);
	}*/
	if(bIsFireButtonHeld)
	{
		//checks if theres ammo in active slot and if the ammo in it is  a charging ammo type 
		if(GetActiveAmmo()!=nullptr)
		{
			switch(GetActiveAmmoState())
			{
				//Only called for Default Ammo, and will spawn ammoBase
			case PDefault:
				if(GetActiveAmmoChargeTime()>0)
				{
					SetActiveAmmoChargeTime(GetActiveAmmoChargeTime()-DeltaTime);
				}
				else
				{
					SetActiveAmmoChargeTime(GetActiveAmmoMaxChargeTime());
					bOnCooldown=false;
				}
				break;
			case PShotgrid:
				if(GetActiveAmmoChargeTime()>0)
				{
					SetActiveAmmoChargeTime(GetActiveAmmoChargeTime()-DeltaTime);
				}
				else
				{
					SetActiveAmmoChargeTime(GetActiveAmmoMaxChargeTime());
					bOnCooldown=false;
				}
				break;
			case PRocketLauncher:
				if(GetActiveAmmoChargeTime()>0)
				{
					SetActiveAmmoChargeTime(GetActiveAmmoChargeTime()-DeltaTime);
				}
				else
				{
					SetActiveAmmoChargeTime(GetActiveAmmoMaxChargeTime());
					bOnCooldown=false;
				}
				break;
			case PRailGun:
				//decrements the charge time
				if(GetActiveAmmoChargeTime()>0)
				{
					SetActiveAmmoChargeTime(GetActiveAmmoChargeTime()-DeltaTime);
				}
				else
				{
					SetActiveAmmoChargeTime(GetActiveAmmoMaxChargeTime());
					bOnCooldown=false;
				}
				break;
			case PFlameThrower:
				if(GetActiveAmmoCount()>0)
				{
					SetActiveAmmoCount(GetActiveAmmoCount()-1);
				}
				else if(GetActiveAmmoCount()<=0)
				{
					if(DamageOverTimeProjectile!=nullptr)
					{
						DamageOverTimeProjectile->DetachFromActor(FDetachmentTransformRules::KeepWorldTransform);
						DamageOverTimeProjectile->SetReadyToDie(true);
					}
				}
				CheckIfActiveAmmoIsEmpty();
				break;
			case PLaserBeam:
				if(GetActiveAmmoCount()>0)
				{
					SetActiveAmmoCount(GetActiveAmmoCount()-1);
				}
				else if(GetActiveAmmoCount()<=0)
				{
					if(DamageOverTimeProjectile!=nullptr)
					{
						DamageOverTimeProjectile->DetachFromActor(FDetachmentTransformRules::KeepWorldTransform);
						DamageOverTimeProjectile->SetReadyToDie(true);
					}
					CheckIfActiveAmmoIsEmpty();
				}
				break;
			default:
				if(GEngine)
				{
					GEngine->AddOnScreenDebugMessage(-1,5.0f,FColor::Red,TEXT("how did u get here?, the active ammo state is PNone"));
				}
				break;
			
			}
		}
	}
	else if(GetActiveAmmoState()==PRailGun)
	{
		if(GetActiveAmmoChargeTime()>0&&GetActiveAmmoChargeTime()<GetActiveAmmoMaxChargeTime())
		{
			SetActiveAmmoChargeTime(GetActiveAmmoMaxChargeTime());
			bOnCooldown=true;
		}
	}
}

void UHusk::Fire(FVector SpawnLocation, FRotator SpawnRotation, UWorld* const World,FActorSpawnParameters ActorSpawnParams)
{
	DamageOverTimeProjectile = nullptr;
	Projectile =nullptr;
	bIsFireButtonHeld = true;
	
	//checks if theres ammo in active slot
	if(GetActiveAmmo()!=nullptr)
	{
		switch(GetActiveAmmoState())
		{
			//Only called for Default Ammo, and will spawn ammoBase
		case PDefault:
			//checks can fire
			if(!bOnCooldown)
			{
				Projectile= World->SpawnActor<AAmmoBase>(GetActiveAmmo(), SpawnLocation, SpawnRotation, ActorSpawnParams);
				bOnCooldown = true;
				//decrements ammo count
				if(GetActiveAmmoCount()>0)
				{
					SetActiveAmmoCount(GetActiveAmmoCount()-1);
				}
				/// if Ammo count is zero, sets it to the default ammo if not already set as default ammo.
				CheckIfActiveAmmoIsEmpty();
			}
			break;
		case PShotgrid:
			//checks can fire
			if(!bOnCooldown)
			{
				Projectile= World->SpawnActor<AAmmoBase>(GetActiveAmmo(), SpawnLocation, SpawnRotation, ActorSpawnParams);
				bOnCooldown = true;
				//decrements ammo count
				if(GetActiveAmmoCount()>0)
				{
					SetActiveAmmoCount(GetActiveAmmoCount()-1);
				}
				/// if Ammo count is zero, sets it to the default ammo if not already set as default ammo.
				CheckIfActiveAmmoIsEmpty();
			}
			break;
		case PRocketLauncher:
			//checks can fire
			if(!bOnCooldown)
			{
				Projectile= World->SpawnActor<AAmmoBase>(GetActiveAmmo(), SpawnLocation, SpawnRotation, ActorSpawnParams);
				bOnCooldown = true;
				//decrements ammo count
				if(GetActiveAmmoCount()>0)
				{
					SetActiveAmmoCount(GetActiveAmmoCount()-1);
				}
				/// if Ammo count is zero, sets it to the default ammo if not already set as default ammo.
				CheckIfActiveAmmoIsEmpty();
			}
			break;
		case PRailGun:
			break;
		case PFlameThrower:
			//spawns bullet while fire button is held
			if(bIsFireButtonHeld&&GetActiveAmmoCount()>0)
			{
				DamageOverTimeProjectile = World->SpawnActor<AAmmoBase>(GetActiveAmmo(), SpawnLocation, SpawnRotation, ActorSpawnParams);
				DamageOverTimeProjectile->AttachToComponent(this->GunMesh, FAttachmentTransformRules::KeepWorldTransform);
			}
			else if(GetActiveAmmoCount()<=0)
			{
				if(DamageOverTimeProjectile!=nullptr)
				{
					DamageOverTimeProjectile->DetachFromActor(FDetachmentTransformRules::KeepWorldTransform);
					DamageOverTimeProjectile->SetReadyToDie(true);
				}
				CheckIfActiveAmmoIsEmpty();
			}
			break;
		case PLaserBeam:
			//spawns bullet while fire button is held
			if(bIsFireButtonHeld&&GetActiveAmmoCount()>0)
			{
				DamageOverTimeProjectile = World->SpawnActor<AAmmoBase>(GetActiveAmmo(), SpawnLocation, SpawnRotation, ActorSpawnParams);
				DamageOverTimeProjectile->AttachToComponent(this->GunMesh, FAttachmentTransformRules::KeepWorldTransform);
			}
			else if(GetActiveAmmoCount()<=0)
			{
				if(DamageOverTimeProjectile!=nullptr)
				{
					DamageOverTimeProjectile->DetachFromActor(FDetachmentTransformRules::KeepWorldTransform);
					DamageOverTimeProjectile->SetReadyToDie(true);
				}
				CheckIfActiveAmmoIsEmpty();
			}
			break;
		default:
			if(GEngine)
			{
				GEngine->AddOnScreenDebugMessage(-1,5.0f,FColor::Red,TEXT("how did u get here?, the active ammo state is PNone"));
			}
			break;
		}
	}
	else
	{
		if(GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1,5.0f,FColor::Red,TEXT("No Active Ammo, Actve slot is above"));
			GEngine->AddOnScreenDebugMessage(-1,5.0f,FColor::Red,FString::FromInt(GetActiveAmmoSlot()));
		}
	}

}
	

void UHusk::ReleaseFire(FVector SpawnLocation, FRotator SpawnRotation, UWorld* const World,
	FActorSpawnParameters ActorSpawnParams)
{
	DamageOverTimeProjectile = nullptr;
	Projectile =nullptr;
	bIsFireButtonHeld = true;
	//checks if theres ammo in active slot
	if(GetActiveAmmo()!=nullptr)
	{
		switch(GetActiveAmmoState())
		{
			//Only called for Default Ammo, and will spawn ammoBase
			case PDefault:
				break;
		case PShotgrid:
			break;
		case PRocketLauncher:
			break;
		case PRailGun:
			//is it fully charged
			if(bOnCooldown)
			{
				//spawns bullet
				Projectile = World->SpawnActor<AAmmoBase>(AmmoOne, SpawnLocation, SpawnRotation, ActorSpawnParams);
				//decrements ammo count
				SetActiveAmmoChargeTime(GetActiveAmmoMaxChargeTime());
				if(GetActiveAmmoCount()>0)
				{
					SetActiveAmmoCount(GetActiveAmmoCount()-1);
				}
				// if Ammo count is zero, sets it to the default ammo if not already set as default ammo.
				CheckIfActiveAmmoIsEmpty();
			}
			break;
		case PFlameThrower:
			if(DamageOverTimeProjectile!=nullptr)
			{
				DamageOverTimeProjectile->DetachFromActor(FDetachmentTransformRules::KeepWorldTransform);
				DamageOverTimeProjectile->SetReadyToDie(true);
			}
			break;
		case PLaserBeam:
			if(DamageOverTimeProjectile!=nullptr)
			{
				DamageOverTimeProjectile->DetachFromActor(FDetachmentTransformRules::KeepWorldTransform);
				DamageOverTimeProjectile->SetReadyToDie(true);
			}
			break;
		default:
			if(GEngine)
			{
				GEngine->AddOnScreenDebugMessage(-1,5.0f,FColor::Red,TEXT("how did u get here?, the active ammo state is PNone"));
			}
			break;
		}
	}
}

void UHusk::CheckIfActiveAmmoIsEmpty()
{
	//check if active ammo slot is not default ammo
	if(GetActiveAmmoSlot()==1||GetActiveAmmoSlot()==2)
	{
		//is active ammo count empty and does active ammo still exist
		if(GetActiveAmmoCount()<=0 && GetActiveAmmo()!=nullptr)
		{
			//"emptying the active ammo, and its ammo state
			SetActiveAmmoState(PNone);
			SetActiveAmmo(nullptr);
			//Are you holding another ammo type?
			if(GetInActiveAmmo()!=nullptr)
			{
				//force player to re-press the fire button when active ammo is being changed
				bIsFireButtonHeld = false;
				//swap from slot one to slot two
				if(GetActiveAmmoSlot()==1)
				{
					ActiveAmmoSlot=2;
				}
				//swap from slot two to slot one
				else if(GetActiveAmmoSlot()==2)
				{
					ActiveAmmoSlot = 1;
				}
			}
			else
			{
				ActiveAmmoSlot=0;
			}
		}
	}
	else
	{
		if (GetActiveAmmoSlot()!=0)
		{
			if(GEngine)
			{
				GEngine->AddOnScreenDebugMessage(-1,5.0f,FColor::Red,TEXT("Can't check if an invalid Ammo slot has no ammo to fire"));
			}
		}
	}
}

bool UHusk::SetGunAmmo(EPickupNames NewGunAmmoState)
{
	//will return false if ammo slots are full of other ammo or the ammo type is none or default
	bool Success = false;

	if(NewGunAmmoState!=PNone&&NewGunAmmoState!=PDefault)
	{
		AAmmoBase* AmmoOneCast;
     	AAmmoBase* AmmoTwoCast;
		//do we have ammo in slot one
		if(AmmoOne == nullptr)
		{
			//do we have ammo in slot 2 and is it the same as the one we picked up
			if(AmmoTwo&&AmmoTwoState==NewGunAmmoState)
			{
				AmmoTwoCast = Cast<AAmmoBase>(GetAmmoInstanceProjectile(AmmoTwoState));
				//add more ammo to slot 2
				AmmoTwoCount+=AmmoTwoCast->AmmoCount;
			}
			else
			{

				AmmoOneState = NewGunAmmoState;
				//set new ammo to slot 1
				AmmoOne = GetAmmoInstance(NewGunAmmoState);
				AmmoOneCast = Cast<AAmmoBase>(GetAmmoInstanceProjectile(AmmoOneState));
				AmmoOneCount = AmmoOneCast->AmmoCount;
				AmmoOneChargeTime =AmmoOneCast->AmmoFireTime;
				AmmoOneMaxChargeTime = AmmoOneCast->AmmoFireTime;
				if(GetActiveAmmoSlot()==0)
				{
					ActiveAmmoSlot = 1;
				}
			
			}
			Success = true;
		}
		//do we have ammo in slot 2
		else if(AmmoTwo == nullptr)
		{
			//do we have ammo in slot 1 and is it the same as the one we picked up
			if(AmmoOne&&AmmoOneState==NewGunAmmoState)
			{
				AmmoOneCast = Cast<AAmmoBase>(GetAmmoInstanceProjectile(AmmoOneState));
				//add more ammo to slot 1
				AmmoOneCount+=AmmoOneCast->AmmoCount;	
			}
			else
			{
				AmmoTwoState  = NewGunAmmoState;
				//set new ammo to slot 2
				AmmoTwo = GetAmmoInstance(NewGunAmmoState);
				AmmoTwoCast = Cast<AAmmoBase>(GetAmmoInstanceProjectile(AmmoTwoState));
				AmmoTwoCount = AmmoTwoCast->AmmoCount;
				AmmoTwoChargeTime = AmmoTwoCast->AmmoFireTime;
				AmmoTwoMaxChargeTime = AmmoTwoCast->AmmoFireTime;
				if(GetActiveAmmoSlot()==0)
				{
					ActiveAmmoSlot = 2;
				}
			}
			Success = true;
		
		}
	}
	return Success;
}

void UHusk::AmmoSwitcher()
{
	//checks currently active ammo
	if(ActiveAmmoSlot==1)
	{
		//checks if slot 2 has ammo
		if(AmmoTwo)
		{
			//switch active ammo
			ActiveAmmoSlot= 2;
		}
	}
	else
	{
		//checks if slot 1 has ammo
		if(AmmoOne)
		{
			//switch active ammo
			ActiveAmmoSlot= 1;
		}
	}
}

void UHusk::ResetWeapon()
{
	//set the default ammo counts
	AmmoOneCount = 0;
	AmmoTwoCount = 0;
	//reset the Active ammo slot
	ActiveAmmoSlot=0;
	//empty both Non-Default ammo slots, and their States
	AmmoOne =nullptr;
	AmmoTwo = nullptr;
	AmmoOneState = PNone;
	AmmoTwoState =PNone;
}

TSubclassOf<AAmmoBase> UHusk::GetAmmoInstance(EPickupNames AmmoSlotState)
{
	switch (AmmoSlotState)
	{
	case PDefault:
		return  AmmoBaseInstance;
	case PShotgrid:
		return  ShotgunAmmoInstance;	
	case PRocketLauncher:
		return  RocketLauncherAmmoInstance;
	case PRailGun:
		return  RailGunAmmoInstance;
	case PFlameThrower:
		return FlamethrowerAmmoInstance;
	case PLaserBeam:
		return  LaserBeamAmmoInstance;
	default:
		//PNone
		return  nullptr;
	}	
}


AAmmoBase* UHusk::GetAmmoInstanceProjectile(EPickupNames AmmoSlotState)
{
	switch (AmmoSlotState)
	{
	case PDefault:
		return  BaseAmmoInstanceProjectile;
	case PShotgrid:
		return  ShotgunAmmoInstanceProjectile;	
	case PRocketLauncher:
		return  RocketLauncherAmmoInstanceProjectile;
	case PRailGun:
		return  RailGunAmmoInstanceProjectile;
	case PFlameThrower:
		return FlamethrowerAmmoInstanceProjectile;
	case PLaserBeam:
		return  LaserBeamAmmoInstanceProjectile;
	default:
		//PNone
		return  nullptr;
	}	
}

int UHusk::GetActiveAmmoSlot()
{
	if(ActiveAmmoSlot>2||ActiveAmmoSlot<0)
	{
		if(GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1,5.0f,FColor::Red,TEXT("WARNING: You are getting an invalid Ammo Slot"));
		}
	}
	return ActiveAmmoSlot;
}

EPickupNames UHusk::GetActiveAmmoState()
{
	switch (ActiveAmmoSlot)
	{
	case 0:
		return DefaultAmmoState;
	case 1:
		return AmmoOneState;
	case 2:
		return AmmoTwoState;
	default:
		if(GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1,5.0f,FColor::Red,TEXT("Can't Get the state of an Invalid Ammo Slot"));
		}
		return PNone;
	}
}

void UHusk::SetActiveAmmoState(EPickupNames NewAmmo)
{
	switch (ActiveAmmoSlot)
	{
	case 0:
		if(GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1,5.0f,FColor::Red,TEXT("Not Allowed to change the Default Ammo state using this function"));
		}
		break;
	case 1:
		AmmoOneState = NewAmmo;
		break;
	case 2:
		AmmoTwoState = NewAmmo;
		break;
	default:
		if(GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1,5.0f,FColor::Red,TEXT("Can't change the state of an Invalid Ammo Slot"));
		}
		break;
	}
}

TSubclassOf<AAmmoBase> UHusk::GetActiveAmmo()
{
	switch (ActiveAmmoSlot)
	{
		case 0:
			return DefaultAmmo;
		case 1:
			return AmmoOne;
		case 2:
			return AmmoTwo;
		default:
			if(GEngine)
			{
				GEngine->AddOnScreenDebugMessage(-1,5.0f,FColor::Red,TEXT("Can't get the Invalid ammo an Invalid Ammo Slot"));
			}
			return nullptr;
	}
	
}

TSubclassOf<AAmmoBase> UHusk::GetInActiveAmmo()
{
	switch (ActiveAmmoSlot)
	{
	case 0:
		if(GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1,5.0f,FColor::Red,TEXT("The Default Ammo isnt an Inactive Ammo" ));
		}
		return DefaultAmmo;
	case 1:
		return AmmoTwo;
	case 2:
		return AmmoOne;
	default:
		if(GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1,5.0f,FColor::Red,TEXT("Can't get the Invalid ammo an Invalid Ammo Slot"));
		}
		return nullptr;
	}
}

void UHusk::SetActiveAmmo(TSubclassOf<AAmmoBase> NewAmmo)
{
	switch (ActiveAmmoSlot)
	{
	case 0:
		if(GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1,5.0f,FColor::Red,TEXT("Not Allowed to change the Default Ammo using this function"));
		}
		break;
	case 1:
		AmmoOne = NewAmmo;
		break;
	case 2:
		AmmoTwo = NewAmmo;
		break;
	default:
		if(GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1,5.0f,FColor::Red,TEXT("Can't set the ammo an Invalid Ammo Slot"));
		}
		break;
	}
}

void UHusk::SetInActiveAmmo(TSubclassOf<AAmmoBase> NewAmmo)
{
	switch (ActiveAmmoSlot)
	{
	case 0:
		if(GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1,5.0f,FColor::Red,TEXT("Not Allowed to change the Default Ammo using this function"));
		}
		break;
	case 1:
		AmmoTwo = NewAmmo;
		break;
	case 2:
		AmmoOne = NewAmmo;
		break;
	default:
		if(GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1,5.0f,FColor::Red,TEXT("Can't set the ammo an Invalid Ammo Slot"));
		}
		break;
	}
}

FString UHusk::GetActiveAmmoName()
{
	switch (ActiveAmmoSlot)
	{
	case 0:
		return DefaultAmmo->GetClass()->GetName();
	case 1:
		return AmmoOne->GetClass()->GetName();
	case 2:
		return AmmoTwo->GetClass()->GetName();
	default:
		if(GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1,5.0f,FColor::Red,TEXT("Can't get the name of an Invalid Ammo Slot"));
		}
		return "Null";
	}
}

int UHusk::GetActiveAmmoCount()
{
	switch (ActiveAmmoSlot)
	{
	case 0:
		return -1;
	case 1:
		return AmmoOneCount;
	case 2:
		return AmmoTwoCount;
	default:
		if(GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1,5.0f,FColor::Red,TEXT("Can't get the Count of an Invalid Ammo Slot"));
		}
		return -1;
	}
}

void UHusk::SetActiveAmmoCount(int NewCount)
{
	switch (ActiveAmmoSlot)
	{
	case 0:
		if(GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1,5.0f,FColor::Red,TEXT("The Default Ammo has no Ammo Count"));
		}
		break;
	case 1:
		AmmoOneCount = NewCount;
		break;
	case 2:
		AmmoTwoCount = NewCount;
		break;
	default:
		if(GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1,5.0f,FColor::Red,TEXT("Can't set the Count of an Invalid Ammo Slot"));
		}
		break;
	}
}

float UHusk::GetActiveAmmoChargeTime()
{
	switch (ActiveAmmoSlot)
	{
	case 0:
		return DefaultAmmoChargeTime;
	case 1:
		return AmmoOneChargeTime;
	case 2:
		return AmmoTwoChargeTime;
	default:
		if(GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1,5.0f,FColor::Red,TEXT("Can't get the charge time of an Invalid Ammo Slot"));
		}
		return -1;
	}
}

void UHusk::SetActiveAmmoChargeTime(float NewChargeTime)
{
	switch (ActiveAmmoSlot)
	{
	case 0:
		DefaultAmmoChargeTime = NewChargeTime;
		break;
	case 1:
		AmmoOneChargeTime = NewChargeTime;
		break;
	case 2:
		AmmoTwoChargeTime = NewChargeTime;
		break;
	default:
		if(GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1,5.0f,FColor::Red,TEXT("Can't set the charge time of an Invalid Ammo Slot"));
		}
		break;
	}
}

float UHusk::GetActiveAmmoMaxChargeTime()
{
	switch (ActiveAmmoSlot)
	{
	case 0:
		return DefaultAmmoMaxChargeTime;
	case 1:
		return AmmoOneMaxChargeTime;
	case 2:
		return AmmoTwoMaxChargeTime;
	default:
		if(GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1,5.0f,FColor::Red,TEXT("Can't get the max Charge time of an Invalid Ammo Slot"));
		}
		return -1;
	}
}

FString UHusk::GetSpecificAmmoName(int AmmoSlotNumber)
{
	switch (AmmoSlotNumber)
	{
	case 0:
		return  DefaultAmmo->GetName();
	case 1:
		return AmmoOne->GetName();
	case 2:
		return AmmoTwo->GetName();
	default:
		if(GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1,5.0f,FColor::Red,TEXT("Can't get the name of an Invalid Ammo Slot"));
		}
		return "Null";
	}
}	

int UHusk::GetSpecificAmmoCount(int AmmoSlotNumber)
{
	switch (AmmoSlotNumber)
	{
	case 0:
		if(GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1,5.0f,FColor::Red,TEXT("The Default Ammo has no Ammo Count"));
		}
		return -1;
	case 1:
		return AmmoOneCount;
	case 2:
		return AmmoTwoCount;
	default:
		if(GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1,5.0f,FColor::Red,TEXT("Can't get the Count of an Invalid Ammo Slot"));
		}
		return -1;
	}
}

void UHusk::SetSpecificAmmoCount(int NewCount,int AmmoSlotNumber)
{
	switch(AmmoSlotNumber)
	{
	case 0:
		if(GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1,5.0f,FColor::Red,TEXT("The Default Ammo has no Ammo Count"));
		}
		break;
	case 1:
		AmmoOneCount = NewCount;
		break;
	case 2:
		AmmoTwoCount = NewCount;
		break;
	default:
		if(GEngine)
		{
			GEngine->AddOnScreenDebugMessage(-1,5.0f,FColor::Red,TEXT("Can't change the Count of an Invalid Ammo Slot"));
		}
		break;
	}
	AmmoOneCount = NewCount;
}

bool UHusk::IsHolding()
{
	return bIsFireButtonHeld;
}


