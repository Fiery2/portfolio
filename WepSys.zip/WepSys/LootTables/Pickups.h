// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "EPickupNames.h"
#include "Pickups.generated.h"

class USphereComponent;
UCLASS()
class BLAST_API APickups : public AActor
{
	GENERATED_BODY()
	
public:	
	/** Sets default values for this actor's properties*/
	APickups();
	/**
	* Loot table
	* key  - the item name
	* value - the items drop chance(weight)
	*/
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "EnemyTables", meta = (AllowProtectedAccess = "true"))
	TMap<TEnumAsByte<EPickupNames>, float> WeightedLootTable;

protected:
	/** Called when the game starts or when spawned*/
	virtual void BeginPlay() override;
	/**class reference to the item dropped*/
	UPROPERTY(EditDefaultsOnly,BlueprintReadOnly, Category=FunctionVars)
	TEnumAsByte<EPickupNames> HeldAmmoName;
	/** Mesh component*/
	UPROPERTY(VisibleDefaultsOnly,BlueprintReadWrite, Category=Mesh)
	UStaticMeshComponent* Mesh;
	/** Sphere collision component */
	UPROPERTY(VisibleDefaultsOnly,BlueprintReadWrite, Category=Projectile)
	USphereComponent* CollisionComponent;
	/**how long the pickup stays on the field */
	UPROPERTY(VisibleDefaultsOnly,BlueprintReadWrite, Category=Projectile)
	float Lifetime;

public:	
	/** Called every frame*/
	virtual void Tick(float DeltaTime) override;
	/** called when projectile hits something
	* @param HitComp component that hit
	* @param OtherActor other actor that was hit
	* @param OtherComp other component that hit
	* @param NormalImpulse impulse the hit would apply
	* @param Hit hit result
	*/
	UFUNCTION()
	virtual void OnHit(UPrimitiveComponent* HitComp, AActor* OtherActor, UPrimitiveComponent* OtherComp, FVector NormalImpulse, const FHitResult& Hit);

	/** called when projectile overlaps something 
	* @param OverlappedComponent component that overlapped
	* @param OtherActor other actor that was overlapped
	* @param OtherComp other component that overlapped
	* @param OtherBodyIndex index the other object is
	* @param bFromSweep if theres a sweep
	* @param SweepResult hit result from the sweep
	*/
	UFUNCTION()
	void OnOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult & SweepResult);
	/**
	* takes an enemy loot table and returns the total of its drop chances
	* @return total of its drop chances
	*/
	float CalculateSum();
	/**
	* takes an enemy loot table and returns a random item in that loot table
	* @return returns a random item in that loot table
	*/
	UFUNCTION(BlueprintCallable, Category = "Tools")
	EPickupNames LootChosen();
	//table setters
	/**
	*  adds new item or modifies the value of an existing item in the WeightedLootTable 
	*  @param ItemName - the key / new item name
	*  @param Value - the new weight for the item
	*/

};


