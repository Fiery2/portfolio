// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

/** Custom movement modes for Characters. */
UENUM(BlueprintType)
enum EPickupNames
{
	PDefault UMETA(DisplayName = "AmmoBase"),
	PShotgrid   UMETA(DisplayName = "ShotGun"),
	PRocketLauncher			UMETA(DisplayName = "RocketLauncher"),
	PRailGun		UMETA(DisplayName = "RailGun"),
	PFlameThrower		UMETA(DisplayName = "Flamethrower"),
	PLaserBeam		UMETA(DisplayName = "LaserBeam"),
	PNone			UMETA(DisplayName = "Empty"),
};
