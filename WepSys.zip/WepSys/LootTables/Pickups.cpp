// Fill out your copyright notice in the Description page of Project Settings.


#include "Pickups.h"

#include "NetworkChar.h"
#include "AmmoBase.h"
#include "Components/SphereComponent.h"

#define COLLISION_PROJECTILE	ECC_GameTraceChannel1
#define COLLISION_PLAYER	ECC_GameTraceChannel2
// Sets default values
APickups::APickups()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;
	//setup collision component details
	if (!CollisionComponent)
	{
		CollisionComponent = CreateDefaultSubobject<USphereComponent>(TEXT("SphereComp"));
		CollisionComponent->BodyInstance.SetCollisionProfileName("Pickup");
		CollisionComponent->OnComponentBeginOverlap.AddDynamic(this, &APickups::OnOverlap);
		CollisionComponent->OnComponentHit.AddDynamic(this, &APickups::OnHit);
		CollisionComponent->SetEnableGravity(true);
		CollisionComponent->SetSimulatePhysics(true);
		// Players can't walk on it
		CollisionComponent->SetWalkableSlopeOverride(FWalkableSlopeOverride(WalkableSlope_Unwalkable, 0.f));
		CollisionComponent->CanCharacterStepUpOn = ECB_No;
		CollisionComponent->SetCollisionResponseToAllChannels(ECR_Overlap);
		CollisionComponent->SetCollisionResponseToChannel(COLLISION_PROJECTILE,ECR_Ignore);
		CollisionComponent->SetCollisionResponseToChannel(ECC_WorldStatic,ECR_Block);
		//CollisionComp->SetCollisionResponseToChannel(COLLISION_Player,ECR_Overlap);
		CollisionComponent->ComponentTags.Add("Pickup");
		CollisionComponent->SetCollisionEnabled(ECollisionEnabled::QueryAndPhysics);
		// Set as root component
		RootComponent = CollisionComponent;
	}
	
	//setup mesh details
	if (!Mesh)
	{
		Mesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("PickupMesh"));
		Mesh->SetupAttachment(RootComponent);
		Mesh->SetEnableGravity(true);
		
		static ConstructorHelpers::FObjectFinder<UStaticMesh>MeshAsset(TEXT("StaticMesh'/Game/BLAST/Gameplay/WepSys/Sphere.Sphere'"));
		UStaticMesh* Asset = MeshAsset.Object;
		Mesh->SetStaticMesh(Asset);
		Mesh->SetRelativeScale3D(FVector(0.5,0.5,0.5));
		Mesh->ComponentTags.Add("Pickup");
		Mesh->SetCollisionResponseToAllChannels(ECR_Overlap);
		Mesh->SetCollisionResponseToChannel(COLLISION_PROJECTILE,ECR_Ignore);
		Mesh->SetCollisionResponseToChannel(ECC_WorldStatic,ECR_Block);
		Mesh->SetCollisionEnabled(ECollisionEnabled::QueryAndPhysics);
		Mesh->SetSimulatePhysics(true);
		Mesh->OnComponentBeginOverlap.AddDynamic(this, &APickups::OnOverlap);
		Mesh->OnComponentHit.AddDynamic(this, &APickups::OnHit);
	}
	Tags.Add("Pickup");
	
	//add the loot drop chances to their tables 
	WeightedLootTable.Add(PShotgrid,1.0);
	WeightedLootTable.Add(PRocketLauncher,1.0);
	WeightedLootTable.Add(PRailGun,1.0);
	/*WeightedLootTable.Add(PFlameThrower,1.0);
	WeightedLootTable.Add(PLaserBeam,1.0);*/
	//set lifetime
	Lifetime=12.0f;
	//replication of drops
	bReplicates = true;
}

//Called when the game starts or when spawned
void APickups::BeginPlay()
{
	Super::BeginPlay();
	//set the current pickup to a specific item 
	EPickupNames Loot = LootChosen();
	//debug purposes only, will need a better wat of displaying contents later
	if(GEngine)
	{
		switch (Loot)
		{
		case PShotgrid:
			GEngine->AddOnScreenDebugMessage(-1,.5f,FColor::Red,TEXT("Shotgun"));
			break;
		case PRocketLauncher:
			GEngine->AddOnScreenDebugMessage(-1,.5f,FColor::Red,TEXT("RocketLauncher"));
			break;
		case PRailGun:
			GEngine->AddOnScreenDebugMessage(-1,.5f,FColor::Red,TEXT("RailGun"));
			break;
		case PFlameThrower:
			GEngine->AddOnScreenDebugMessage(-1,.5f,FColor::Red,TEXT("FlameThrower"));
			break;
		case PLaserBeam:
			GEngine->AddOnScreenDebugMessage(-1,.5f,FColor::Red,TEXT("LaseBeam"));
			break;
		default:
			GEngine->AddOnScreenDebugMessage(-1,.5f,FColor::Red,TEXT("Empty or Ammo Base"));
			break;
		}
	}
	HeldAmmoName = Loot;
}

// Called every frame
void APickups::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
	//updates de-spawn timer
	if(Lifetime<=0)
	{
		Destroy();
	}
	else
	{
		Lifetime-=DeltaTime;
	}
}

void APickups::OnHit(UPrimitiveComponent* HitComp, AActor* OtherActor, UPrimitiveComponent* OtherComp,
	FVector NormalImpulse, const FHitResult& Hit)
{
	//is the hit character a player
	ANetworkChar* PlayerGrabbing = Cast<ANetworkChar>(OtherActor);
	if (PlayerGrabbing)
	{
		//have the player try to "pickup" the item
		if(PlayerGrabbing->GetGun()->SetGunAmmo(HeldAmmoName))
		{
			Destroy();
		}
		else
		{
			if(GEngine)
			{
				GEngine->AddOnScreenDebugMessage(-1,.5f,FColor::Red,TEXT("Failed to Pickup"));
			}
		}
	}
}

void APickups::OnOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp,int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult)
{
	//is the overlaped character a player
	ANetworkChar* PlayerGrabbing = Cast<ANetworkChar>(OtherActor);
	if (PlayerGrabbing)
	{
		//have the player try to "pickup" the item
		if(PlayerGrabbing->GetGun()->SetGunAmmo(HeldAmmoName))
		{
			Destroy();
		}
		else
		{
			if(GEngine)
			{
				GEngine->AddOnScreenDebugMessage(-1,.5f,FColor::Red,TEXT("Failed to Pickup"));
			}
		}
	}
	else
	{
		/*if(GEngine)
		{
		GEngine->AddOnScreenDebugMessage(-1,.5f,FColor::Red,TEXT("Not a player");
		}*/
	}

}

float APickups::CalculateSum()
{
	//make a total tracker variable and an array of drop chances 
	float RunningTotal=0;
	TArray<float>Chances;
	WeightedLootTable.GenerateValueArray(Chances);
	//add up and return the total drop chances
	for (float Chance : Chances)
	{
		RunningTotal+=Chance;
	}
	
	return RunningTotal;
}

EPickupNames APickups::LootChosen()
{
	EPickupNames LootChoice = PNone;
	//get the total of the values in the chosen table
	const float ValueSum = CalculateSum();
	
	//choose a random number between 0 and the total
	float RandomChance = FMath::RandRange(0.0,ValueSum);
	//get an array of all possible loot options in chosen loot table
	TArray<TEnumAsByte<EPickupNames>>LootList;
	WeightedLootTable.GenerateKeyArray(LootList);
	//figure out which drop corresponds with the chosen random number
	for (EPickupNames Loot : LootList)
	{
		//if the value of the current drop is bigger than the random number then its the chosen drop
		if(RandomChance<*WeightedLootTable.Find(Loot))
		{
			LootChoice = Loot;
			break;
		}
		//otherwise, subtract the current value from the random number, and repeat
		RandomChance = RandomChance-*WeightedLootTable.Find(Loot);
	}
	return LootChoice;
}

